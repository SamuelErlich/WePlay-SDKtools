'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../Resources/sdktools_probe.js'), 'utf8');

function element(tag, children = [], extra = {}) {
    const value = {
        tagName: tag.toUpperCase(), hidden: false,
        getAttribute: () => null,
        getBoundingClientRect: () => ({ left: 10, top: 20, width: 100, height: 50 }),
        _style: { display: 'block', visibility: 'visible', opacity: '1' },
        ...extra
    };
    value.firstElementChild = children[0] || null;
    children.forEach((child, i) => { child.nextElementSibling = children[i + 1] || null; });
    return value;
}
function node(name, children = [], extra = {}) {
    return { name, active: true, activeInHierarchy: true, opacity: 255,
        position: { x: 1, y: 2, z: 0 }, children,
        getContentSize: () => ({ width: 40, height: 60 }), ...extra };
}
function run(options = {}) {
    const root = options.dom || element('html', [element('body')]);
    const window = {
        innerWidth: 390, innerHeight: 844, devicePixelRatio: 3,
        getComputedStyle: el => el._style
    };
    Object.defineProperties(window, Object.getOwnPropertyDescriptors(options.window || {}));
    const document = { documentElement: root };
    Object.defineProperties(document, Object.getOwnPropertyDescriptors(options.document || {}));
    const context = { window, document, ...(options.clock ? { Date: options.clock } : {}) };
    const result = vm.runInNewContext(source, context, { timeout: 2000 });
    return JSON.parse(JSON.stringify(result));
}

test('plain DOM produces JSON-safe schema with CSS coordinates and no engine assumption', () => {
    const result = run();
    assert.equal(result.schema, 'sdktools.web.v1');
    assert.equal(result.readOnly, true);
    assert.equal(result.viewport.devicePixelRatio, 3);
    assert.equal(result.dom.elements.length, 2);
    assert.equal(result.engine.cocos.status, 'not-exposed');
    assert.equal(result.coverage.readErrorCount, 0);
    assert.equal(result.coverage.truncated, false);
});

test('never reads sensitive text, form values, cookies, URL, canvas pixels or storage', () => {
    let forbiddenReads = 0;
    const forbidden = () => { forbiddenReads++; throw new Error('DO_NOT_EXPORT_SECRET'); };
    const input = element('input', [], { getAttribute: key => key === 'role' ? 'textbox' : forbidden() });
    ['value', 'textContent', 'innerText', 'innerHTML', 'id', 'className'].forEach(key => Object.defineProperty(input, key, { get: forbidden }));
    const canvas = element('canvas', [], { width: 780, height: 1688, getContext: forbidden, toDataURL: forbidden });
    const w = {};
    ['location', 'localStorage', 'sessionStorage', 'fetch', 'XMLHttpRequest'].forEach(key => Object.defineProperty(w, key, { get: forbidden, enumerable: false }));
    const d = {};
    ['cookie', 'URL', 'referrer', 'title'].forEach(key => Object.defineProperty(d, key, { get: forbidden }));
    const result = run({ dom: element('html', [input, canvas]), window: w, document: d });
    assert.equal(forbiddenReads, 0);
    assert.equal(result.dom.canvases[0].backingWidth, 780);
    assert.equal(result.dom.elements[1].role, 'textbox');
    assert.ok(!JSON.stringify(result).includes('DO_NOT_EXPORT_SECRET'));
    assert.ok(!Object.hasOwn(result.dom.elements[1], 'value'));
});

test('omits hidden DOM branches, transparent nodes and offscreen boxes', () => {
    const hidden = element('div', [element('button')], { _style: { display: 'none' } });
    const transparent = element('div', [element('canvas')], { _style: { opacity: '0' } });
    const offscreen = element('button', [], { getBoundingClientRect: () => ({ left: 500, top: 0, width: 50, height: 50 }) });
    const result = run({ dom: element('html', [hidden, transparent, offscreen, element('button')]) });
    assert.equal(result.dom.elements.length, 2);
    assert.equal(result.dom.coverage.visited, 5);
    assert.equal(result.dom.coverage.excludedHidden, 2);
    assert.equal(result.dom.coverage.excludedOutsideOrEmpty, 1);
    assert.equal(result.dom.canvases.length, 0);
});

test('DOM visits are capped rather than scanning the entire page', () => {
    const result = run({ dom: element('html', Array.from({ length: 1000 }, () => element('div'))) });
    assert.equal(result.dom.coverage.visited, 200);
    assert.equal(result.dom.elements.length, 200);
    assert.equal(result.dom.coverage.truncated, true);
});

test('partial and throwing Cocos APIs fail closed without leaking exception contents', () => {
    assert.equal(run({ window: { cc: {} } }).engine.cocos.status, 'partial-api');
    const result = run({ window: { cc: { director: { getScene() { throw new Error('SECRET_TOKEN'); } } } } });
    assert.equal(result.engine.cocos.status, 'scene-unavailable');
    assert.equal(result.coverage.readErrorCount, 1);
    assert.ok(result.coverage.readErrors.includes('cocos.getScene'));
    assert.ok(!JSON.stringify(result).includes('SECRET_TOKEN'));
});

test('Cocos only includes confirmed active nodes and excludes transparent subtrees', () => {
    const hidden = node('secret-card', [node('secret-child')], { activeInHierarchy: false });
    const transparent = node('hidden-tile', [node('hidden-subtree')], { opacity: 0 });
    const unknown = node('unknown');
    delete unknown.activeInHierarchy;
    const visible = node('SheepCard1', [], { position: { x: NaN, y: Infinity, z: -3 } });
    const scene = node('Scene', [hidden, transparent, unknown, visible]);
    const result = run({ window: { cc: { director: { getScene: () => scene } } } });
    const nodes = result.engine.cocos.nodes;
    assert.deepEqual(nodes.map(x => x.name), ['Scene', 'SheepCard1']);
    assert.equal(nodes[1].parentIndex, 0);
    assert.deepEqual(nodes[1].localPosition, { x: null, y: null, z: -3 });
    assert.equal(nodes[1].candidate, 'name-heuristic-only');
    assert.equal(nodes[1].screenVisibilityConfirmed, false);
    assert.equal(result.engine.cocos.coverage.excludedInactive, 1);
    assert.equal(result.engine.cocos.coverage.excludedTransparent, 1);
    assert.equal(result.engine.cocos.coverage.skippedUnknownActivity, 1);
    assert.ok(!JSON.stringify(result).includes('secret-card'));
});

test('Cocos 3 public UI components are optional and supply size/opacity without mutation', () => {
    function UITransform() {}
    function UIOpacity() {}
    const scene = node('Scene', [node('Tile', [], {
        getComponent: type => type === UITransform ? { contentSize: { width: 80, height: 90 } } : { opacity: 128 }
    }), node('Transparent', [], {
        getComponent: type => type === UIOpacity ? { opacity: 0 } : null
    })]);
    const result = run({ window: { cc: { UITransform, UIOpacity, director: { getScene: () => scene } } } });
    assert.equal(result.engine.cocos.nodes.length, 2);
    assert.equal(result.engine.cocos.nodes[1].uiOpacity, 128);
    assert.deepEqual(result.engine.cocos.nodes[1].untransformedSize, { width: 80, height: 90 });
    assert.equal(scene.children[0].opacity, 255);
});

test('Cocos traversal caps large sibling arrays and safely handles cycles', () => {
    const scene = node('Scene');
    scene.children = [scene, ...Array.from({ length: 900 }, (_, i) => node('Tile' + i))];
    const result = run({ window: { cc: { director: { getScene: () => scene } } } });
    assert.equal(result.engine.cocos.coverage.visited, 400);
    assert.equal(result.engine.cocos.nodes.length, 400);
    assert.equal(result.engine.cocos.coverage.cycles, 1);
    assert.equal(result.engine.cocos.coverage.truncated, true);
});

test('long names are bounded, untrusted roles rejected, invalid rectangles omitted', () => {
    const bad = element('div', [], {
        getAttribute: () => 'PERSONAL_SECRET',
        getBoundingClientRect: () => ({ left: 1, top: 1, width: Infinity, height: 1 })
    });
    const scene = node('Card' + 'x'.repeat(200));
    const result = run({ dom: element('html', [bad]), window: { cc: { director: { getScene: () => scene } } } });
    assert.equal(result.engine.cocos.nodes[0].name.length, 64);
    assert.equal(result.dom.elements.length, 1);
    assert.ok(!JSON.stringify(result).includes('PERSONAL_SECRET'));
});

test('node names shaped like URLs or addresses are redacted', () => {
    const scene = node('Scene', [node('https://example.test/private?token=SECRET'), node('person@example.test')]);
    const result = run({ window: { cc: { director: { getScene: () => scene } } } });
    assert.deepEqual(result.engine.cocos.nodes.map(x => x.name), ['Scene', '[redacted-name]', '[redacted-name]']);
    assert.ok(!JSON.stringify(result).includes('example.test'));
});

test('throwing child-array metadata and DOM getters remain JSON-safe', () => {
    const children = new Proxy([], { get(target, prop) { if (prop === 'length') throw new Error('SECRET'); return target[prop]; } });
    const scene = node('Scene', children);
    const badElement = element('div');
    Object.defineProperty(badElement, 'firstElementChild', { get() { throw new Error('SECRET'); } });
    const result = run({ dom: element('html', [badElement]), window: { cc: { director: { getScene: () => scene } } } });
    assert.equal(result.engine.cocos.nodes.length, 1);
    assert.ok(result.coverage.readErrors.includes('cocos.childCount'));
    assert.ok(result.coverage.readErrors.includes('dom.child'));
    assert.ok(!JSON.stringify(result).includes('SECRET'));
});

test('cooperative deadline reports incomplete coverage and skips engine work', () => {
    let time = 0;
    let sceneCalls = 0;
    const result = run({
        clock: { now: () => { time += 25; return time; } },
        dom: element('html', Array.from({ length: 100 }, () => element('div'))),
        window: { cc: { director: { getScene() { sceneCalls++; return node('Scene'); } } } }
    });
    assert.equal(result.coverage.deadlineExceeded, true);
    assert.equal(result.coverage.truncated, true);
    assert.ok(result.dom.coverage.visited < 200);
    assert.equal(result.engine.cocos.status, 'skipped-time-budget');
    assert.equal(sceneCalls, 0);
});
