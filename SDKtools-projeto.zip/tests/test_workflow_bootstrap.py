"""Exercise the actual inline workflow bootstrap without GitHub or network calls."""
from pathlib import Path
import stat
import tempfile
import textwrap
import unittest
import zipfile

WORKFLOW = Path(__file__).resolve().parents[1] / '.github' / 'workflows' / 'compilar.yml'
SOURCE = WORKFLOW.read_text(encoding='utf-8').split('# SDKTOOLS_BOOTSTRAP_BEGIN\n', 1)[1]
SOURCE = textwrap.dedent(SOURCE.split('# SDKTOOLS_BOOTSTRAP_END', 1)[0])
BOOTSTRAP = {'__name__': 'sdktools_bootstrap_test'}
exec(compile(SOURCE, str(WORKFLOW), 'exec'), BOOTSTRAP)
BootstrapError = BOOTSTRAP['BootstrapError']


class BootstrapTests(unittest.TestCase):
    def make_zip(self, path, prefix=''):
        with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            for name in BOOTSTRAP['EXPECTED_FILES']:
                archive.writestr(prefix + name, b'fixture')

    def test_unpackaged_sources_and_wrapped_zip(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = root / 'repository'
            workspace.mkdir()
            # An uploaded ZIP takes precedence over stale unpacked project files.
            for name in BOOTSTRAP['EXPECTED_FILES']:
                target = workspace / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(b'stale fixture')
            self.make_zip(workspace / 'SDKtools-projeto.zip', 'SDKtools/')
            project = BOOTSTRAP['locate_project'](workspace, root / 'runner')
            self.assertEqual(project, root / 'runner' / 'sdktools-project' / 'SDKtools')
            self.assertTrue(BOOTSTRAP['is_project'](project))
            self.assertEqual(BOOTSTRAP['locate_project'](project, root / 'unused'), project)

    def test_root_zip(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            self.make_zip(root / 'project.zip')
            self.assertEqual(BOOTSTRAP['extract_project'](root / 'project.zip', root / 'out'), root / 'out')

    def test_rejects_traversal_symlink_duplicates_and_file_parent(self):
        cases = [('../escape', None), ('link', stat.S_IFLNK | 0o777), ('same-case', None), ('file-parent', None)]
        for name, mode in cases:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                archive_path = root / 'project.zip'
                with zipfile.ZipFile(archive_path, 'w') as archive:
                    if name == 'same-case':
                        archive.writestr('Sources/A.m', b'a')
                        archive.writestr('sources/a.m', b'b')
                    elif name == 'file-parent':
                        archive.writestr('Sources', b'a')
                        archive.writestr('Sources/A.m', b'b')
                    else:
                        info = zipfile.ZipInfo(name)
                        if mode is not None:
                            info.create_system = 3
                            info.external_attr = mode << 16
                        archive.writestr(info, b'bad')
                with self.assertRaises(BootstrapError):
                    BOOTSTRAP['extract_project'](archive_path, root / 'out')
                self.assertFalse((root / 'escape').exists())

    def test_size_limit_and_incomplete_project(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            archive_path = root / 'project.zip'
            with zipfile.ZipFile(archive_path, 'w') as archive:
                archive.writestr('only.txt', b'not a complete project')
            with self.assertRaises(BootstrapError):
                BOOTSTRAP['extract_project'](archive_path, root / 'incomplete')
            previous = BOOTSTRAP['MAX_EXPANDED_BYTES']
            try:
                BOOTSTRAP['MAX_EXPANDED_BYTES'] = 1
                with self.assertRaises(BootstrapError):
                    BOOTSTRAP['extract_project'](archive_path, root / 'limited')
            finally:
                BOOTSTRAP['MAX_EXPANDED_BYTES'] = previous


if __name__ == '__main__':
    unittest.main()
