"""Offline checks for exact-asset selection and downloaded-file integrity."""
import hashlib
import importlib.util
from pathlib import Path
import tempfile
import unittest
import zipfile

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "fetch_ipa_release.py"
SPEC = importlib.util.spec_from_file_location("fetch_ipa_release", SCRIPT)
fetch = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(fetch)


class ReleaseDownloadTests(unittest.TestCase):
    def test_same_repository_and_complete_inputs(self):
        fetch.validate_inputs("owner/repo", "owner/repo", "input/v1", "base.ipa")
        with self.assertRaises(fetch.DownloadError):
            fetch.validate_inputs("other/repo", "owner/repo", "input/v1", "base.ipa")
        for tag, name in (("", "base.ipa"), ("v1", ""), ("v1", "../../base.ipa"),
                          ("v1", "https://example.com/base.ipa"), ("v1\n", "base.ipa")):
            with self.subTest(tag=tag, name=name), self.assertRaises(fetch.DownloadError):
                fetch.validate_inputs("owner/repo", "owner/repo", tag, name)

    def test_exact_name_across_pages(self):
        desired = {"id": 2, "name": "base.ipa", "state": "uploaded", "size": 100}
        pages = [[{"id": 1, "name": "base-copy.ipa", "state": "uploaded", "size": 100}], [desired]]
        self.assertEqual(fetch.select_asset(pages, "base.ipa"), desired)
        with self.assertRaises(fetch.DownloadError):
            fetch.select_asset(pages, "*.ipa")
        with self.assertRaises(fetch.DownloadError):
            fetch.select_asset([[desired, desired]], "base.ipa")

    def test_size_state_and_id_validation(self):
        for update in ({"size": 0}, {"size": fetch.MAX_ASSET_BYTES + 1},
                       {"state": "new"}, {"id": True}):
            asset = {"id": 2, "name": "base.ipa", "state": "uploaded", "size": 100}
            asset.update(update)
            with self.subTest(update=update), self.assertRaises(fetch.DownloadError):
                fetch.select_asset([[asset]], "base.ipa")

    def test_binary_size_digest_and_zip(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "base.ipa"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("Payload/example.app/Info.plist", b"fixture")
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            asset = {"size": path.stat().st_size, "digest": "sha256:" + digest}
            self.assertEqual(fetch.verify_download(path, asset), digest)
            with self.assertRaises(fetch.DownloadError):
                fetch.verify_download(path, {"size": 1})
            with self.assertRaises(fetch.DownloadError):
                fetch.verify_download(path, {"size": path.stat().st_size, "digest": "sha256:" + "0" * 64})
            path.write_bytes(b"not a ZIP")
            with self.assertRaises(fetch.DownloadError):
                fetch.verify_download(path, {"size": path.stat().st_size})


if __name__ == "__main__":
    unittest.main()
