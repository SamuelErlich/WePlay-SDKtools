"""Synthetic-only package and capture checks; never loads executable code."""
import hashlib
import json
from pathlib import Path
import plistlib
import stat
import struct
import sys
import tempfile
import unittest
import zipfile

TOOLS = Path(__file__).resolve().parents[1] / "tools"
sys.path.insert(0, str(TOOLS))
from prepare_ipa import MachO, MH_DYLIB, MH_EXECUTE, Limits, PreparationError, INJECT_PATH, prepare
from analyze_session import analyze, load_session


def dylib_command(name, command=0xD):
    text = name.encode() + b"\0"
    size = (24 + len(text) + 7) & ~7
    return (struct.pack("<IIIIII", command, size, 24, 0, 0, 0) + text).ljust(size, b"\0")


def macho(kind=MH_EXECUTE, *, section_offset=1024, cryptid=0, minimum=(15, 0, 0), dependency=None):
    total = max(4096, section_offset + 64)
    segment = struct.pack("<II16sQQQQiiII", 0x19, 152, b"__TEXT", 0x100000000, total, 0, total, 5, 5, 1, 0)
    section = struct.pack("<16s16sQQIIIIIIII", b"__text", b"__TEXT", 0x100000000 + section_offset,
                          64, section_offset, 2, 0, 0, 0x80000400, 0, 0, 0)
    encoded_version = minimum[0] << 16 | minimum[1] << 8 | minimum[2]
    commands = [segment + section, struct.pack("<IIIIII", 0x32, 24, 2, encoded_version, encoded_version, 0),
                struct.pack("<IIIIII", 0x2C, 24, section_offset, 64, cryptid, 0)]
    if kind == MH_DYLIB:
        commands.append(dylib_command("@rpath/SDKtools.dylib"))
    if dependency:
        commands.append(dylib_command(dependency, 0xC))
    command_bytes = b"".join(commands)
    header = struct.pack("<IiiIIIII", 0xFEEDFACF, 0x100000C, 0, kind, len(commands), len(command_bytes), 0, 0)
    if len(header + command_bytes) > section_offset:
        raise ValueError("Synthetic section overlaps headers")
    blob = bytearray(total)
    blob[:len(header + command_bytes)] = header + command_bytes
    blob[section_offset:section_offset + 64] = bytes(range(64))
    return bytes(blob)


class PackageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.ipa = self.root / "source.ipa"
        self.dylib = self.root / "SDKtools.dylib"
        self.resources = self.root / "SDKtools.bundle"
        self.resources.mkdir()
        (self.resources / "icon.png").write_bytes(b"test-resource")
        self.dylib.write_bytes(macho(MH_DYLIB))
        self.output = self.root / "prepared-UNSIGNED.ipa"

    def tearDown(self):
        self.temp.cleanup()

    def make_ipa(self, binary=None, extra=()):
        metadata = {"CFBundleExecutable": "App", "CFBundleIdentifier": "test.sdktools", "MinimumOSVersion": "15.0"}
        with zipfile.ZipFile(self.ipa, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("Payload/App.app/Info.plist", plistlib.dumps(metadata))
            archive.writestr("Payload/App.app/App", binary or macho())
            archive.writestr("Payload/App.app/asset.bin", bytes(range(256)) * 4096)
            archive.writestr("Payload/App.app/_CodeSignature/CodeResources", b"stale-main-signature")
            archive.writestr("Payload/App.app/Frameworks/Other.framework/_CodeSignature/CodeResources", b"nested-preserved")
            for name, data in extra:
                archive.writestr(name, data)

    def run_prepare(self):
        return prepare(self.ipa, self.dylib, self.resources, self.output)

    def test_injection_and_unmodified_content_preserved(self):
        self.make_ipa()
        original_digest = hashlib.sha256(self.ipa.read_bytes()).hexdigest()
        result = self.run_prepare()
        self.assertEqual(result["load_command"]["status"], "injected")
        self.assertIn("UNSIGNED", result["status"])
        self.assertEqual(hashlib.sha256(self.ipa.read_bytes()).hexdigest(), original_digest)
        with zipfile.ZipFile(self.ipa) as old, zipfile.ZipFile(self.output) as new:
            self.assertIsNone(new.testzip())
            for name in old.namelist():
                if name == "Payload/App.app/App" or name.startswith("Payload/App.app/_CodeSignature/"):
                    continue
                self.assertEqual(old.read(name), new.read(name), name)
            binary = new.read("Payload/App.app/App")
            parsed = MachO(binary, expected_type=MH_EXECUTE)
            self.assertEqual(parsed.dependencies.count(INJECT_PATH), 1)
            self.assertEqual(binary[1024:], old.read("Payload/App.app/App")[1024:])
            self.assertEqual(new.read("Payload/App.app/SDKtools.bundle/icon.png"), b"test-resource")
            self.assertNotIn("Payload/App.app/_CodeSignature/CodeResources", new.namelist())
            self.assertIn("Payload/App.app/Frameworks/Other.framework/_CodeSignature/CodeResources", new.namelist())

    def test_no_padding_rejected_atomically(self):
        self.make_ipa(macho(section_offset=240))
        with self.assertRaisesRegex(PreparationError, "Insufficient header padding"):
            self.run_prepare()
        self.assertFalse(self.output.exists())
        self.assertFalse(list(self.root.glob(".sdktools-*")))

    def test_nonzero_padding_rejected(self):
        blob = bytearray(macho())
        blob[232] = 0x41
        self.make_ipa(bytes(blob))
        with self.assertRaisesRegex(PreparationError, "not entirely zero"):
            self.run_prepare()

    def test_encryption_rejected(self):
        self.make_ipa(macho(cryptid=1))
        with self.assertRaisesRegex(PreparationError, "cryptid"):
            self.run_prepare()
        self.assertFalse(self.output.exists())

    def test_path_traversal_rejected(self):
        for bad_name in ("../escape", "/absolute", "Payload/../escape", "Payload\\escape", "C:/escape", "Payload//escape"):
            with self.subTest(bad_name=bad_name):
                self.make_ipa(extra=[(bad_name, b"bad")])
                with self.assertRaises(PreparationError):
                    self.run_prepare()
                self.assertFalse(self.output.exists())

    def test_duplicate_and_symlink_entries_rejected(self):
        self.make_ipa(extra=[("Payload/App.app/Info.plist", b"duplicate")])
        with self.assertRaisesRegex(PreparationError, "Duplicate"):
            self.run_prepare()
        self.make_ipa()
        with zipfile.ZipFile(self.ipa, "a") as archive:
            info = zipfile.ZipInfo("Payload/App.app/link")
            info.create_system = 3
            info.external_attr = (stat.S_IFLNK | 0o777) << 16
            archive.writestr(info, b"../../outside")
        with self.assertRaisesRegex(PreparationError, "Symlink"):
            self.run_prepare()

    def test_existing_output_not_overwritten(self):
        self.make_ipa()
        self.output.write_bytes(b"preserve-me")
        with self.assertRaisesRegex(PreparationError, "new path"):
            self.run_prepare()
        self.assertEqual(self.output.read_bytes(), b"preserve-me")
        with self.assertRaises(PreparationError):
            prepare(self.ipa, self.dylib, self.resources, self.ipa)

    def test_duplicate_dependency_is_not_added(self):
        binary = macho(dependency=INJECT_PATH)
        self.make_ipa(binary)
        result = self.run_prepare()
        self.assertEqual(result["load_command"]["status"], "already_present")
        with zipfile.ZipFile(self.output) as archive:
            self.assertEqual(archive.read("Payload/App.app/App"), binary)

    def test_newer_dylib_target_rejected(self):
        self.make_ipa()
        self.dylib.write_bytes(macho(MH_DYLIB, minimum=(16, 0, 0)))
        with self.assertRaisesRegex(PreparationError, "newer iOS"):
            self.run_prepare()

    def test_resource_symlink_rejected(self):
        self.make_ipa()
        (self.resources / "link").symlink_to(self.dylib)
        with self.assertRaisesRegex(PreparationError, "Symlink"):
            self.run_prepare()

    def test_size_guard(self):
        self.make_ipa()
        with self.assertRaisesRegex(PreparationError, "size limit"):
            prepare(self.ipa, self.dylib, self.resources, self.output, limits=Limits(total_bytes=1024, entry_bytes=1024))


class SessionTests(unittest.TestCase):
    def session(self, events):
        return {"schema": "sdktools.session.v1", "session_id": "synthetic-test", "started_at": "2026-10-14T12:00:00Z",
                "duration_ms": 1000, "app": {"bundle_id": "test.app"}, "capture_config": {}, "events": events}

    def test_sheep_names_do_not_confirm_visual_identity(self):
        events = [{"type": "screen", "t_ms": 0, "data": {"controllers": ["WPLGSheepGameHomeViewController"]}},
                  {"type": "touch", "t_ms": 10, "data": {"phase": "began", "touch_id": 1, "x": 32, "y": 128, "normalized_x": 0.1, "normalized_y": 0.2, "coordinate_space": "window_points"}},
                  {"type": "touch", "t_ms": 11, "data": {"phase": "ended", "touch_id": 1, "x": 32, "y": 128, "normalized_x": 0.1, "normalized_y": 0.2, "coordinate_space": "window_points"}},
                  {"type": "screenshot", "t_ms": 20, "data": {"file": "frames/0001.jpg", "status": "ok", "width_px": 320, "height_px": 640}}]
        summary = analyze(self.session(events), files={"session.json", "frames/0001.jpg"})
        self.assertEqual(summary["sheep_correspondence"]["status"], "requires_manual_visual_confirmation")
        self.assertEqual(summary["sheep_correspondence"]["class_name_indicators"], ["WPLGSheepGameHomeViewController"])
        self.assertEqual(summary["touch_summary"]["completed_sequences"], 1)
        self.assertEqual(summary["warning_counts"], {})

    def test_temporal_and_reference_warnings(self):
        events = [{"type": "screen", "t_ms": 800, "data": {}},
                  {"type": "screen", "t_ms": 100, "data": {}},
                  {"type": "screenshot", "t_ms": 1200, "data": {"file": "frames/no.jpg", "status": "ok", "width_px": 320, "height_px": 640}}]
        counts = analyze(self.session(events), files={"session.json"})["warning_counts"]
        self.assertIn("nonmonotonic_time", counts)
        self.assertIn("event_after_session_end", counts)
        self.assertIn("missing_frame_file", counts)

    def test_zip_export_read_without_extracting(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "export.zip"
            with zipfile.ZipFile(path, "w") as archive:
                archive.writestr("session.json", json.dumps(self.session([])))
                archive.writestr("frames/test.jpg", b"synthetic")
            data, files = load_session(path)
            self.assertEqual(data["schema"], "sdktools.session.v1")
            self.assertIn("frames/test.jpg", files)


if __name__ == "__main__":
    unittest.main(verbosity=2)
