#!/usr/bin/env bash
# Build SDKtools with Apple's compiler and iPhoneOS SDK; no signing identity needed.
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
DIST_DIR="$PROJECT_DIR/dist"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "SDKtools requires macOS with Xcode and the iPhoneOS SDK. Use the GitHub Actions workflow." >&2
  exit 2
fi
if ! command -v xcrun >/dev/null 2>&1; then
  echo "xcrun was not found. Select a full Xcode installation using xcode-select." >&2
  exit 2
fi

SDK_PATH="$(xcrun --sdk iphoneos --show-sdk-path)"
CLANG_PATH="$(xcrun --sdk iphoneos --find clang)"
SDK_VERSION="$(xcrun --sdk iphoneos --show-sdk-version)"
if [[ ! -d "$SDK_PATH/System/Library/Frameworks/UIKit.framework" ]]; then
  echo "The selected Xcode does not provide a complete iPhoneOS SDK." >&2
  exit 2
fi
if [[ ! -f "$PROJECT_DIR/Resources/sdktools_probe.js" ]]; then
  echo "Missing Resources/sdktools_probe.js." >&2
  exit 2
fi

SOURCES=()
while IFS= read -r -d '' source_file; do
  SOURCES+=("$source_file")
done < <(find "$PROJECT_DIR/Sources" -type f -name '*.m' -print0)
if [[ ${#SOURCES[@]} -eq 0 ]]; then
  echo "No Objective-C sources were found in Sources/." >&2
  exit 2
fi

mkdir -p "$BUILD_DIR/objects" "$DIST_DIR"
# Clear only known generated outputs; an unsuccessful build must not reuse a binary.
rm -f "$BUILD_DIR/SDKtools.dylib" "$DIST_DIR/SDKtools-build.zip"
rm -rf "$BUILD_DIR/SDKtools.bundle" "$BUILD_DIR/SDKtools.dylib.dSYM"

OBJECTS=()
: > "$BUILD_DIR/compiler.log"
for source_file in "${SOURCES[@]}"; do
  relative_source="${source_file#"$PROJECT_DIR/Sources/"}"
  object_file="$BUILD_DIR/objects/${relative_source%.m}.o"
  mkdir -p "$(dirname "$object_file")"
  "$CLANG_PATH" \
    -arch arm64 \
    -isysroot "$SDK_PATH" \
    -miphoneos-version-min=15.0 \
    -fobjc-arc -fblocks -fmodules \
    -Wall -Wextra -O2 -g \
    -I "$PROJECT_DIR/Sources" \
    -c "$source_file" -o "$object_file" \
    2>&1 | tee -a "$BUILD_DIR/compiler.log"
  OBJECTS+=("$object_file")
done

"$CLANG_PATH" \
  -arch arm64 \
  -isysroot "$SDK_PATH" \
  -miphoneos-version-min=15.0 \
  -dynamiclib -fobjc-arc -g \
  "${OBJECTS[@]}" \
  -framework Foundation \
  -framework UIKit \
  -framework QuartzCore \
  -framework WebKit \
  -lobjc -lz \
  -Wl,-install_name,@rpath/SDKtools.dylib \
  -Wl,-headerpad_max_install_names \
  -o "$BUILD_DIR/SDKtools.dylib" \
  2>&1 | tee -a "$BUILD_DIR/compiler.log"

ditto "$PROJECT_DIR/Resources" "$BUILD_DIR/SDKtools.bundle"
cat > "$BUILD_DIR/SDKtools.bundle/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleIdentifier</key><string>local.sdktools.resources</string>
  <key>CFBundleName</key><string>SDKtools</string>
  <key>CFBundlePackageType</key><string>BNDL</string>
  <key>CFBundleShortVersionString</key><string>0.1.0</string>
  <key>CFBundleVersion</key><string>1</string>
</dict>
</plist>
PLIST
plutil -lint "$BUILD_DIR/SDKtools.bundle/Info.plist"

xcrun dsymutil "$BUILD_DIR/SDKtools.dylib" -o "$BUILD_DIR/SDKtools.dylib.dSYM"
# Ad hoc signing is a local integrity check only. The final IPA needs the user's
# valid signing identity/profile, including a fresh signature on this dylib.
codesign --force --sign - --timestamp=none "$BUILD_DIR/SDKtools.dylib"
codesign --verify --strict "$BUILD_DIR/SDKtools.dylib"
xcrun lipo -verify_arch arm64 "$BUILD_DIR/SDKtools.dylib"
{
  xcodebuild -version
  "$CLANG_PATH" --version
  xcrun otool -hv "$BUILD_DIR/SDKtools.dylib"
  xcrun otool -L "$BUILD_DIR/SDKtools.dylib"
  xcrun otool -l "$BUILD_DIR/SDKtools.dylib"
  codesign -dvv "$BUILD_DIR/SDKtools.dylib" 2>&1
} > "$BUILD_DIR/build-checks.txt"

python3 - "$PROJECT_DIR" "$SDK_VERSION" <<'PY'
import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import zipfile

root = pathlib.Path(sys.argv[1])
build = root / 'build'
def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

metadata = {
    'schema': 'sdktools.build.v1',
    'generated_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'platform': 'iphoneos',
    'architecture': 'arm64',
    'minimum_ios': '15.0',
    'sdk_version': sys.argv[2],
    'xcode': subprocess.check_output(['xcodebuild', '-version'], text=True).strip(),
    'install_name': '@rpath/SDKtools.dylib',
    'signature': 'ad-hoc; final IPA signing is still required',
    'device_runtime_tested': False,
    'source_sha256': {
        str(path.relative_to(root)): sha256(path)
        for folder in ('Sources', 'Resources')
        for path in sorted((root / folder).rglob('*')) if path.is_file()
    },
    'dylib_sha256': sha256(build / 'SDKtools.dylib'),
}
(build / 'build-metadata.json').write_text(
    json.dumps(metadata, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

items = [build / 'SDKtools.dylib', build / 'SDKtools.bundle',
         build / 'SDKtools.dylib.dSYM', build / 'build-metadata.json',
         build / 'build-checks.txt', build / 'compiler.log']
archive = root / 'dist' / 'SDKtools-build.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
    for item in items:
        files = sorted(item.rglob('*')) if item.is_dir() else [item]
        for path in files:
            if path.is_file():
                zf.write(path, str(path.relative_to(build)))
    readme = root / 'README.md'
    if readme.is_file():
        zf.write(readme, 'README.md')
print(f'Built {archive}')
print('Library build complete. compilar.yml integrates it into the base IPA next; device testing is still required.')
PY
