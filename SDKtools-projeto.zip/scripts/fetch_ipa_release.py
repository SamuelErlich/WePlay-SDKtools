#!/usr/bin/env python3
"""Download one exact IPA asset from the current GitHub repository's release.

Read-only GitHub API operations using the workflow's short-lived GH_TOKEN.
No URLs, access tokens or passwords are accepted as script arguments or printed.
The original IPA is downloaded into input/ and is never uploaded by this script.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from urllib.parse import quote
import zipfile

MAX_ASSET_BYTES = 2 * 1024**3


class DownloadError(ValueError):
    pass


def validate_inputs(repository: str, workflow_repository: str, tag: str, asset_name: str) -> None:
    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repository):
        raise DownloadError("GH_REPO must identify the current owner/repository.")
    if repository != workflow_repository:
        raise DownloadError("Only a release from this workflow's own repository is supported.")
    if not tag or tag != tag.strip() or len(tag) > 255 or any(ord(c) < 32 or ord(c) == 127 for c in tag):
        raise DownloadError("Provide a nonempty release tag without surrounding whitespace or control characters.")
    if (not asset_name or asset_name != asset_name.strip() or
            any(c in asset_name for c in "/\\") or
            any(ord(c) < 32 or ord(c) == 127 for c in asset_name) or
            not asset_name.lower().endswith(".ipa")):
        raise DownloadError("A release tag requires an exact .ipa asset filename (not a URL or path).")


def select_asset(pages: object, name: str) -> dict:
    if not isinstance(pages, list) or not all(isinstance(page, list) for page in pages):
        raise DownloadError("GitHub returned an unexpected release asset list.")
    matches = [asset for page in pages for asset in page
               if isinstance(asset, dict) and asset.get("name") == name]
    if len(matches) != 1:
        raise DownloadError("The release must contain exactly one asset with the requested filename.")
    asset = matches[0]
    if type(asset.get("id")) is not int or asset["id"] <= 0 or asset.get("state") != "uploaded":
        raise DownloadError("The selected release asset is not available for download.")
    if type(asset.get("size")) is not int or not 0 < asset["size"] <= MAX_ASSET_BYTES:
        raise DownloadError("The selected asset is empty or exceeds the 2 GiB download limit.")
    return asset


def gh_json(endpoint: str, *, paginate: bool = False) -> object:
    command = ["gh", "api", "--hostname", "github.com", "--method", "GET",
               "--header", "Accept: application/vnd.github+json", endpoint]
    if paginate:
        command.extend(["--paginate", "--slurp"])
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            check=False, timeout=120)
    if result.returncode:
        # Do not relay CLI diagnostics that might include signed URLs or credentials.
        raise DownloadError("GitHub could not read the release. Check the tag and repository Contents: read permission.")
    try:
        return json.loads(result.stdout)
    except (ValueError, UnicodeDecodeError) as exc:
        raise DownloadError("GitHub returned invalid JSON.") from exc


def verify_download(path: Path, asset: dict) -> str:
    if path.stat().st_size != asset["size"]:
        raise DownloadError("Downloaded size does not match the release asset metadata.")
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            hasher.update(chunk)
    digest = hasher.hexdigest()
    advertised = asset.get("digest")
    if isinstance(advertised, str) and advertised.startswith("sha256:"):
        if advertised.lower() != "sha256:" + digest:
            raise DownloadError("Downloaded SHA-256 does not match the release asset metadata.")
    if not zipfile.is_zipfile(path):
        raise DownloadError("The selected file is not a ZIP-based IPA. Upload the .ipa, not a RAR wrapper.")
    return digest


def main() -> int:
    partial = None
    try:
        repository = os.environ.get("GH_REPO", "")
        workflow_repository = os.environ.get("GITHUB_REPOSITORY", "")
        tag = os.environ.get("IPA_RELEASE_TAG", "")
        name = os.environ.get("IPA_ASSET_NAME", "")
        validate_inputs(repository, workflow_repository, tag, name)
        if not os.environ.get("GH_TOKEN"):
            raise DownloadError("GH_TOKEN is required; the workflow supplies its own read-only token.")
        prefix = f"repos/{repository}/releases"
        release = gh_json(f"{prefix}/tags/{quote(tag, safe='')}")
        if not isinstance(release, dict) or type(release.get("id")) is not int or release["id"] <= 0:
            raise DownloadError("GitHub did not return a valid release identifier.")
        pages = gh_json(f"{prefix}/{release['id']}/assets?per_page=100", paginate=True)
        asset = select_asset(pages, name)

        output = Path(__file__).resolve().parent.parent / "input" / "base.ipa"
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.exists():
            raise DownloadError("input/base.ipa already exists; refusing to replace it.")
        descriptor, temporary = tempfile.mkstemp(prefix=".base-", suffix=".partial", dir=output.parent)
        partial = Path(temporary)
        with os.fdopen(descriptor, "wb") as handle:
            result = subprocess.run(
                ["gh", "api", "--hostname", "github.com", "--method", "GET",
                 "--header", "Accept: application/octet-stream", f"{prefix}/assets/{asset['id']}"],
                stdout=handle, stderr=subprocess.PIPE, check=False, timeout=900)
        if result.returncode:
            raise DownloadError("GitHub could not download the selected release asset.")
        digest = verify_download(partial, asset)
        os.link(partial, output)  # Atomic publication without overwriting an existing IPA.
        partial.unlink()
        partial = None
        print(f"Downloaded one exact release asset into input/base.ipa ({asset['size']} bytes).")
        print(f"SHA-256: {digest}")
        return 0
    except (DownloadError, OSError, subprocess.TimeoutExpired) as exc:
        message = str(exc) if isinstance(exc, DownloadError) else "A local operation or GitHub request failed; no IPA was published."
        print(f"SDKtools IPA download failed: {message}", file=sys.stderr)
        return 2
    finally:
        if partial is not None:
            partial.unlink(missing_ok=True)


if __name__ == "__main__":
    raise SystemExit(main())
