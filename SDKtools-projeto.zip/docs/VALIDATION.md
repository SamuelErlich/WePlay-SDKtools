# Validação desta entrega

Data: 14/10/2026. Ambiente de verificação local: Linux, Node e Python. Nenhum certificado utilizado.

| Verificação | Resultado |
|---|---|
| Probe JavaScript com DOM/Cocos simulados | 12 testes aprovados |
| Empacotamento/análise, asset de release e bootstrap do ZIP | 22 testes Python aprovados |
| Sintaxe Bash, AST Python e estrutura YAML | Aprovados |
| Parser sobre IPA fornecido | 7.198 entradas aceitas; 1.376 bytes de padding Mach-O disponíveis para comando de 72 bytes |
| Código Objective-C | Revisado estaticamente; compilação ainda não executada |
| GitHub Actions | Workflow preparado; execução manual pelo usuário no próprio repositório |
| IPA com SDKtools | Ainda não gerado nesta entrega de fontes |
| Assinatura final/GBox/iPhone | Não testados |

Comandos executados na raiz do projeto:

```bash
node --test tests/test_*.js
python3 -m unittest discover -s tests -p 'test_*.py' -v
bash -n scripts/build.sh
```

Os testes usam arquivos sintéticos e não provam compatibilidade do menu com uma partida real. O executável original foi somente lido; a alteração experimental de header usada para conferir o espaço ocorreu em memória, sem gravar outro IPA.

Achados da revisão corrigidos: aritmética de tempo, API Objective-C de filhos de UIViewController, encerramento da tarefa de fundo, área de toque do indicador, horário de solicitação/conclusão do probe e encerramento em falha de gravação. Os módulos de captura também explicitam eventos omitidos, frames com falha e exportação parcial.

O workflow será a primeira compilação nativa. Após o build, a validação necessária é instalar uma cópia assinada, entrar/sair do jogo, confirmar os controles de toque e inspecionar as imagens e o JSON exportados.

O compilar.yml agora extrai o ZIP de fontes e exige o IPA base. Quatro testes adicionais exercitam o bootstrap real do workflow, incluindo precedência do ZIP, fonte descompactada e rejeições de arquivos inseguros. O sucesso do job exige upload do IPA final, e não apenas da biblioteca.
