# SDKtools — decisão de implementação, 14/10/2026

## Objetivo pedido

Menu flutuante discreto chamado SDKtools; primeiro recurso para capturar o caminho até o Crazy Alpaca, uma partida, os toques e elementos disponíveis; exportação JSON para análise posterior. Compilação pelo GitHub Actions, conforme orientação posterior do usuário.

## Decisões

Escolhida uma dylib UIKit carregada pelo executável WePlay. A interface é inserida na janela normal ativa, sem janela global acima de outros aplicativos. Um observador de gestos não reconhece nem cancela gestos. O conteúdo da tela é amostrado em imagens, sem áudio. WebKit é consultado com uma expressão de leitura em seu contexto de página, sem substituir o bridge do app ou registrar interceptadores de rede.

Alternativas consideradas: colocar o menu somente no JavaScript dependeria do payload ainda não recuperado; implementá-lo em Unity dependeria de vínculo com o gameplay ainda não estabelecido. UIKit permite iniciar a captura antes de entrar no jogo.

## Fluxo e limites

Botão → iniciar → imagens e eventos → marcar entrada → parar → drenar gravações → JSON → ZIP → compartilhamento pelo usuário. Captura encerra quando o app fica inativo ou chega a 5 minutos. Operações de disco são serializadas; uma captura de imagem pendente por vez; limites de eventos, memória de fila e disco são explícitos. ZIP original de sessão é mantido localmente até o usuário gerenciar seus dados. Não há envio de telemetria.

Capturas visuais e metadados têm alcance diferente: posição Cocos local não equivale a retângulo do card na tela. `cardCandidateHeuristic` é uma heurística de nome, não identificação semântica. Nós ativos não comprovam visibilidade ou ausência de oclusão. Hashes e nomes de classe não confirmam sozinhos o título comercial do minijogo.

## Integração e verificação

Build no runner macOS/Xcode, arm64, mínimo iOS15, dependências de sistema. A integração modifica uma cópia e adiciona uma dependência Mach-O em padding verificado; recusa casos que exigiriam deslocar seções. Certificados não fazem parte do build. Assinatura final e testes em aparelho são etapas separadas. Raio-x, resolução de tabuleiro e autoplay não fazem parte desta implementação inicial.

## Ajuste de entrega

O usuário gerencia o próprio GitHub. O workflow compilar.yml aceita o ZIP do projeto fechado na raiz ou fontes descompactados. A integração com o IPA base de uma release do mesmo repositório é obrigatória: execução bem-sucedida entrega WePlay-SDKtools-unsigned.ipa. Não há modo de sucesso somente com a biblioteca.
