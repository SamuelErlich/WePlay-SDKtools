# Formato de captura SDKtools v1

O exportador produz um ZIP com `session.json` na raiz e imagens JPEG em `frames/`.
O arquivo registra a navegação e a partida observadas durante uma sessão iniciada
pelo usuário. O ZIP não é um vídeo contínuo: as imagens são amostras da janela,
com eventos e tempos para comparação. Uma captura não demonstra o conteúdo de
cartas cobertas nem determina automaticamente as regras da partida.

## Objeto principal

| Campo | Tipo | Significado |
|---|---|---|
| `schema` | string | Valor `sdktools.session.v1`. |
| `session_id` | string | Identificador local da sessão. |
| `started_at` | string | Instante ISO 8601 com fuso horário. |
| `duration_ms` | número | Duração baseada em relógio monotônico. |
| `app` | objeto | `bundle_id`, `version` e `build` do aplicativo que hospeda o menu. |
| `capture_config` | objeto | Configuração efetiva, limites, renderizador e suas limitações. |
| `capture_stats` | objeto | Contadores `requested`, `dropped`, `written` e `failed` das imagens. |
| `event_count` | inteiro | Número de eventos efetivamente gravados. |
| `events_accepted` | inteiro | Número de eventos aceitos antes da finalização. |
| `warnings` | array | Avisos do gravador; uma exportação pode conter falhas parciais. |
| `events` | array | Eventos da sessão; estrutura descrita abaixo. |

`capture_config` inclui o limite de eventos, o limite de armazenamento, largura
máxima de imagem de 1170 px, JPEG com qualidade 0,65 e `storage: "local_only"`.
O controlador encerra a captura após 300 segundos ou ao perder atividade.
Campos adicionais podem ser acrescentados mantendo esta versão; consumidores
devem ignorar campos desconhecidos e preservar o arquivo original.

## Eventos

Cada evento tem `seq` (sequência local), `type`, `t_ms` (tempo relativo ao início,
em milissegundos) e `data` (objeto). A sequência não é um identificador do servidor
nem uma ordem de execução de comandos do jogo.

| `type` | Conteúdo relevante de `data` |
|---|---|
| `session_start`, `session_stop` | Limites da sessão do gravador. |
| `touch` | `touch_id`, `phase`, coordenadas, classe da view tocada, contagem e tipo de toque. |
| `screenshot` | Estado da captura, dimensões e caminho da imagem quando gravada. |
| `screen` | Classes de controladores, árvore limitada de views nativas e retângulos. |
| `web_snapshot` | Identificador local de WKWebView, retângulo na janela e resultado da sonda web. |
| `mark` | Marcador acionado pelo usuário ou pelo fluxo da ferramenta. |
| `lifecycle` | Pausas, retomada e perda de atividade. |
| `error` | Componente e código de uma operação que falhou. |

### Toques e sistemas de coordenadas

No gravador atual, `touch.data.x` e `y` são **pontos UIKit da janela**, não pixels.
`normalized_x` e `normalized_y` são as mesmas posições divididas pela largura e
altura da janela. `coordinate_space` tem valor `window_points`. Um gesto pode
terminar fora da janela e produzir uma coordenada normalizada fora de `[0, 1]`.
O `touch_id` associa `began`, `moved`, `ended` ou `cancelled` dentro da sessão.
Eventos de movimento são amostrados; não constituem uma trajetória de precisão
para reprodução automática. Toques nos controles do próprio SDKtools são excluídos.

Para sobrepor um toque à imagem de mesma janela/orientação, use aproximadamente
`pixel_x = normalized_x × width_px` e `pixel_y = normalized_y × height_px`.
Compare os tempos e os limites da janela antes de juntar registros; imagens e
toques não são necessariamente emitidos no mesmo instante.

### Imagens

Quando `status` é `captured`, `file` aponta para um membro relativo do ZIP,
por exemplo `frames/frame_000001.jpg`, e `width_px`/`height_px` são dimensões
em pixels. `bytes` informa o tamanho gravado. Estados como `renderer_failed`,
`write_failed`, `disk_limit`, `writer_stopped` e `no_visible_window` não garantem
que uma imagem exista. Consulte também `draw_succeeded` e
`webgl_content_not_guaranteed`.

O renderizador é `UIKit.drawViewHierarchyInRect`. Conteúdo WebGL, protegido ou
composto por outros mecanismos pode ficar ausente mesmo quando outras partes
da interface aparecem. A interpretação exige abrir as imagens; o analisador
Python não realiza OCR nem reconhecimento de cartas.

### Hierarquia nativa

`screen.data.controllers` contém nomes das classes de controladores encontrados.
`views` contém objetos com `id`, `parent`, `class`, `frame` e `interactive`.
`frame` usa pontos da janela. `truncated` indica que o limite de travessia foi
atingido. `occlusion_tested: false` significa que uma view listada pode estar
atrás de outra; não se deve tratá-la como um elemento comprovadamente visível.
Textos de campos e valores de entrada não são incluídos nessa árvore.

### Sonda de WKWebView

`web_snapshot.data.snapshot.schema` é `sdktools.web.v1`.
O resultado tem `viewport`, `dom`, `engine.cocos` e cobertura/limitações.
A árvore DOM descreve geometria e tipos de elementos sem despejar valores de
campos, cookies, armazenamento local ou tráfego de rede. Canvas/WebGL é
identificado como superfície, não convertido em uma lista completa de cartas.

Quando a página expõe a API compatível, `engine.cocos.status` pode ser
`scene-available`. Outros estados incluem `not-exposed`, `partial-api`,
`scene-unavailable` e `skipped-time-budget`. A presença de uma cena não prova que
todos os elementos da partida foram capturados. Nomes e transformações de nós
ativos podem ajudar na correlação; não são uma descrição automática das regras
nem revelam, por si só, o significado de objetos cobertos.

### Marcador de entrada no Crazy Alpaca

O botão de marcação registra:

```json
{
  "type": "mark",
  "t_ms": 42000,
  "data": {
    "label": "entered_crazy_alpaca",
    "source": "user",
    "confirmed_by_analysis": false
  }
}
```

Esse marcador é uma indicação do usuário. Para confirmar a correspondência
visual com o módulo `Sheep`, compare imagens do caminho, a tela de entrada e a
partida com as classes observadas perto desses mesmos instantes. Encontrar um
nome contendo `Sheep` sem essa comparação não é confirmação visual.

## Análise local

Requer Python 3.9+; usa apenas a biblioteca padrão:

```bash
python3 tools/analyze_session.py SDKtools-session.zip --output resumo.json
```

Também aceita `session.json` diretamente. Se uma pasta `frames/` estiver ao
lado, verifica as referências locais; se ela faltar, relata cobertura não
verificada. No ZIP, valida nomes, duplicatas, tipos de arquivo, tamanhos e CRC
sem extrair caminhos. O arquivo de resumo precisa ser novo: não é sobrescrito.

O resultado `sdktools.analysis.v1` inclui contagens, fases de toque, sequência
temporal, avisos, disponibilidade das imagens, classes contendo `Sheep` e
lacunas de cobertura. `sheep_correspondence.status` permanece
`requires_manual_visual_confirmation`; o script nunca promove nomes de classes
ou uma marcação do usuário a uma conclusão visual.

## Preparação opcional do IPA

Depois de compilar a dylib arm64 e criar `SDKtools.bundle`, o empacotador pode
produzir uma cópia nova sem assinatura válida:

```bash
python3 tools/prepare_ipa.py \
  --ipa original.ipa \
  --dylib build/SDKtools.dylib \
  --resources build/SDKtools.bundle \
  --output SDKtools-UNSIGNED.ipa
```

O programa exige Mach-O arm64 de dispositivo, executável principal sem
criptografia ativa (`cryptid == 0`) e deployment target da dylib compatível com
`MinimumOSVersion`. Acrescenta `LC_LOAD_DYLIB` para
`@executable_path/Frameworks/SDKtools.dylib` somente quando há espaço de cabeçalho
existente, comprovadamente zerado, antes dos dados referenciados. Não desloca
seções. Uma dependência idêntica existente é reaproveitada; caminhos SDKtools
ambíguos são recusados.

O IPA original não é alterado. Arquivos são copiados em streaming; a ferramenta
remove somente `_CodeSignature` do aplicativo principal, substitui seus destinos
SDKtools e preserva as demais entradas. Assinaturas incorporadas nos executáveis
e assinaturas de componentes aninhados podem continuar presentes, mas isso não
torna a cópia assinada ou instalável. O assinador precisa reassinar recursivamente
o código interno e, por último, o aplicativo principal com identidade e perfil
adequados. Não são usados certificados, senhas ou chaves por estes scripts.

Antes de publicar a saída, o empacotador compara SHA-256 de cada entrada com os
bytes copiados, verifica CRC via `ZipFile.testzip()` e relê o comando Mach-O.
A publicação é atômica e recusa sobrescrever arquivos. A validação não substitui
compilação com Xcode, assinatura, instalação e teste no aparelho/GBox.

Testes sintéticos:

```bash
python3 -m unittest discover -s tests -p test_package.py -v
```
