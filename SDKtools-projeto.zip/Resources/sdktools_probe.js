/*
 * SDKtools one-shot, read-only WKWebView diagnostic probe.
 * evaluateJavaScript returns the plain object produced by this expression.
 * No event listeners, persistent globals, network requests, asset reads,
 * text/input values, URLs, cookies or storage access are used.
 *
 * Public Cocos interfaces consulted:
 * https://docs.cocos.com/creator/2.4/api/en/classes/Node.html
 * https://docs.cocos.com/creator/3.8/api/en/class/Node
 * https://docs.cocos.com/creator/3.8/api/en/class/Director
 * https://docs.cocos.com/creator/3.8/api/en/class/UIOpacity
 * https://docs.cocos.com/creator/3.8/manual/en/ui-system/components/editor/ui-transform.html
 */
(function () {
    'use strict';

    var LIMITS = { domVisited: 200, cocosVisited: 400, durationMs: 100, errors: 20, nameLength: 64 };
    var errorCount = 0;
    var errors = [];
    var deadlineExceeded = false;
    var started = Date.now();
    var win = typeof window === 'object' && window ? window : {};
    var doc = typeof document === 'object' && document ? document : null;

    function error(code) {
        errorCount += 1;
        if (errors.length < LIMITS.errors) errors.push(code);
    }
    function read(getter, code, fallback) {
        try { return getter(); } catch (_) { error(code); return fallback; }
    }
    function finite(value) {
        return typeof value === 'number' && Number.isFinite(value) ? value : null;
    }
    function nonnegative(value) {
        value = finite(value);
        return value !== null && value >= 0 ? value : null;
    }
    function boolean(value) { return typeof value === 'boolean' ? value : null; }
    function expired() {
        if (Date.now() - started >= LIMITS.durationMs) deadlineExceeded = true;
        return deadlineExceeded;
    }
    function name(value) {
        if (typeof value !== 'string') return null;
        // Node names are identifiers, never component values, labels or asset paths.
        // Do not export names shaped like a URL, path, address or query string.
        if (/[\/\\:@?#=&]/.test(value)) return '[redacted-name]';
        return value.replace(/[\u0000-\u001f\u007f]/g, '').slice(0, LIMITS.nameLength);
    }
    function vector(value) {
        if (!value || typeof value !== 'object') return null;
        return {
            x: finite(read(function () { return value.x; }, 'position.x', null)),
            y: finite(read(function () { return value.y; }, 'position.y', null)),
            z: finite(read(function () { return value.z; }, 'position.z', null))
        };
    }
    function dimensions(value) {
        if (!value || typeof value !== 'object') return null;
        return {
            width: nonnegative(read(function () { return value.width; }, 'size.width', null)),
            height: nonnegative(read(function () { return value.height; }, 'size.height', null))
        };
    }

    var viewport = {
        coordinateSpace: 'layout-viewport-css-pixels',
        width: nonnegative(read(function () { return win.innerWidth; }, 'viewport.width', null)),
        height: nonnegative(read(function () { return win.innerHeight; }, 'viewport.height', null)),
        devicePixelRatio: nonnegative(read(function () { return win.devicePixelRatio; }, 'viewport.scale', null)),
        visualViewport: null
    };
    var vv = read(function () { return win.visualViewport; }, 'viewport.visual', null);
    if (vv) viewport.visualViewport = {
        offsetLeft: finite(read(function () { return vv.offsetLeft; }, 'viewport.offsetLeft', null)),
        offsetTop: finite(read(function () { return vv.offsetTop; }, 'viewport.offsetTop', null)),
        width: nonnegative(read(function () { return vv.width; }, 'viewport.visualWidth', null)),
        height: nonnegative(read(function () { return vv.height; }, 'viewport.visualHeight', null)),
        scale: nonnegative(read(function () { return vv.scale; }, 'viewport.visualScale', null))
    };

    var dom = {
        status: doc ? 'available' : 'document-unavailable',
        coordinateSpace: 'layout-viewport-css-pixels',
        visibilityAssessment: 'style-and-viewport-intersection; clipping-and-occlusion-not-resolved',
        elements: [], canvases: [],
        coverage: { visited: 0, emitted: 0, excludedHidden: 0, excludedOutsideOrEmpty: 0, skippedUnknown: 0, cycles: 0, truncated: false }
    };
    var roles = new Set(('alert alertdialog application article banner blockquote button caption cell checkbox code columnheader combobox complementary contentinfo definition deletion dialog directory document emphasis feed figure form generic grid gridcell group heading img insertion link list listbox listitem log main marquee math menu menubar menuitem menuitemcheckbox menuitemradio meter navigation none note option paragraph presentation progressbar radio radiogroup region row rowgroup rowheader scrollbar search searchbox separator slider spinbutton status strong subscript suggestion superscript switch tab table tablist tabpanel term textbox time timer toolbar tooltip tree treegrid treeitem').split(' '));

    function bounds(element) {
        var rect = read(function () { return element.getBoundingClientRect(); }, 'dom.bounds', null);
        if (!rect) return null;
        var box = read(function () {
            return { x: finite(rect.left), y: finite(rect.top), width: nonnegative(rect.width), height: nonnegative(rect.height) };
        }, 'dom.rect', null);
        return box && box.x !== null && box.y !== null && box.width !== null && box.height !== null ? box : null;
    }
    function onScreen(box) {
        return box && box.width > 0 && box.height > 0 &&
            viewport.width !== null && viewport.height !== null &&
            box.x < viewport.width && box.y < viewport.height &&
            box.x + box.width > 0 && box.y + box.height > 0;
    }

    if (doc) {
        // A bounded lazy DFS avoids querySelectorAll('*') allocating an unbounded list.
        var domRoot = read(function () { return doc.documentElement; }, 'dom.root', null);
        var domStack = domRoot ? [{ node: domRoot, isRoot: true }] : [];
        var domSeen = new Set();
        while (domStack.length && dom.coverage.visited < LIMITS.domVisited && !expired()) {
            var frame = domStack.pop();
            var element = frame.node;
            if (!element || domSeen.has(element)) { dom.coverage.cycles += 1; continue; }
            domSeen.add(element);
            dom.coverage.visited += 1;
            if (!frame.isRoot) {
                var sibling = read(function () { return element.nextElementSibling; }, 'dom.sibling', null);
                if (sibling) domStack.push({ node: sibling, isRoot: false });
            }
            var style = read(function () { return win.getComputedStyle(element); }, 'dom.style', null);
            if (!style) { dom.coverage.skippedUnknown += 1; continue; }
            var hidden = read(function () {
                return element.hidden === true || style.display === 'none' || style.visibility === 'hidden' ||
                    style.visibility === 'collapse' || style.contentVisibility === 'hidden' ||
                    (style.opacity !== '' && Number(style.opacity) === 0);
            }, 'dom.visibility', true);
            if (hidden) { dom.coverage.excludedHidden += 1; continue; }
            var child = read(function () { return element.firstElementChild; }, 'dom.child', null);
            if (child) domStack.push({ node: child, isRoot: false });
            var box = bounds(element);
            if (!onScreen(box)) { dom.coverage.excludedOutsideOrEmpty += 1; continue; }
            var rawTag = read(function () { return element.tagName; }, 'dom.tag', null);
            var tag = typeof rawTag === 'string' && /^[a-z][a-z0-9-]{0,31}$/i.test(rawTag) ? rawTag.toLowerCase() : 'unknown';
            var rawRole = read(function () { return element.getAttribute('role'); }, 'dom.role', null);
            var role = typeof rawRole === 'string' && roles.has(rawRole) ? rawRole : null;
            var item = { index: dom.elements.length, tag: tag, role: role, bounds: box };
            dom.elements.push(item);
            if (tag === 'canvas') dom.canvases.push({
                elementIndex: item.index, bounds: box,
                backingWidth: nonnegative(read(function () { return element.width; }, 'canvas.width', null)),
                backingHeight: nonnegative(read(function () { return element.height; }, 'canvas.height', null))
            });
        }
        dom.coverage.emitted = dom.elements.length;
        dom.coverage.truncated = domStack.length > 0;
    }

    var cocos = {
        status: 'not-exposed', apiSurface: 'window.cc.director.getScene',
        coordinateSpace: 'node-local-parent-units; not-screen-pixels',
        visibilityAssessment: 'activeInHierarchy-and-public-opacity; screen-visibility-and-occlusion-unconfirmed',
        nodes: [],
        coverage: { visited: 0, emitted: 0, excludedInactive: 0, excludedTransparent: 0, skippedUnknownActivity: 0, cycles: 0, truncated: false }
    };
    var cc = read(function () { return win.cc; }, 'cocos.global', null);
    if (cc) {
        cocos.status = 'partial-api';
        var director = read(function () { return cc.director; }, 'cocos.director', null);
        var getScene = director && read(function () { return director.getScene; }, 'cocos.getSceneMethod', null);
        if (typeof getScene === 'function' && !expired()) {
            var scene = read(function () { return getScene.call(director); }, 'cocos.getScene', null);
            cocos.status = scene ? 'scene-available' : 'scene-unavailable';
            var stack = scene ? [{ node: scene, parentIndex: null }] : [];
            var seen = new Set();
            while (stack.length && cocos.coverage.visited < LIMITS.cocosVisited && !expired()) {
                var current = stack.pop();
                var node = current.node;
                // Child iterators are expanded lazily to bound work and memory even with huge sibling arrays.
                if (current.children) {
                    if (current.next < current.length) {
                        var childIndex = current.next++;
                        stack.push(current);
                        var nextNode = read(function () { return current.children[childIndex]; }, 'cocos.child', null);
                        stack.push({ node: nextNode, parentIndex: current.parentIndex });
                    }
                    continue;
                }
                if (!node || (typeof node !== 'object' && typeof node !== 'function')) continue;
                if (seen.has(node)) { cocos.coverage.cycles += 1; continue; }
                seen.add(node);
                cocos.coverage.visited += 1;
                var active = read(function () { return node.activeInHierarchy; }, 'cocos.activity', null);
                if (active !== true) {
                    if (active === false) cocos.coverage.excludedInactive += 1;
                    else cocos.coverage.skippedUnknownActivity += 1;
                    continue;
                }
                var opacity = finite(read(function () { return node.opacity; }, 'cocos.opacity', null));
                var uiOpacity = null;
                var uiTransform = null;
                var getComponent = read(function () { return node.getComponent; }, 'cocos.getComponentMethod', null);
                if (typeof getComponent === 'function') {
                    // Use exported public classes only. A module-only Cocos build may expose neither.
                    var opacityType = read(function () { return cc.UIOpacity; }, 'cocos.opacityType', null);
                    var transformType = read(function () { return cc.UITransform; }, 'cocos.transformType', null);
                    if (typeof opacityType === 'function') uiOpacity = read(function () { return getComponent.call(node, opacityType); }, 'cocos.uiOpacity', null);
                    if (typeof transformType === 'function') uiTransform = read(function () { return getComponent.call(node, transformType); }, 'cocos.uiTransform', null);
                }
                var componentOpacity = uiOpacity ? finite(read(function () { return uiOpacity.opacity; }, 'cocos.uiOpacityValue', null)) : null;
                if (opacity === 0 || componentOpacity === 0) { cocos.coverage.excludedTransparent += 1; continue; }
                var nodeName = name(read(function () { return node.name; }, 'cocos.name', null));
                var position = vector(read(function () { return node.position; }, 'cocos.position', null));
                var size = uiTransform ? dimensions(read(function () { return uiTransform.contentSize; }, 'cocos.contentSize', null)) : null;
                if (!size) {
                    var getContentSize = read(function () { return node.getContentSize; }, 'cocos.getContentSizeMethod', null);
                    if (typeof getContentSize === 'function') size = dimensions(read(function () { return getContentSize.call(node); }, 'cocos.getContentSize', null));
                }
                var index = cocos.nodes.length;
                cocos.nodes.push({
                    index: index, parentIndex: current.parentIndex,
                    name: nodeName, type: 'CocosNode', activeInHierarchy: true,
                    active: boolean(read(function () { return node.active; }, 'cocos.localActivity', null)),
                    localPosition: position, untransformedSize: size,
                    opacity: opacity, uiOpacity: componentOpacity,
                    candidate: nodeName && /card|tile|sheep/i.test(nodeName) ? 'name-heuristic-only' : null,
                    screenVisibilityConfirmed: false
                });
                var children = read(function () { return node.children; }, 'cocos.children', null);
                var childCount = Array.isArray(children) ? nonnegative(read(function () { return children.length; }, 'cocos.childCount', null)) : null;
                if (childCount) stack.push({ children: children, next: 0, length: Math.floor(childCount), parentIndex: index });
            }
            cocos.coverage.emitted = cocos.nodes.length;
            cocos.coverage.truncated = stack.some(function (entry) { return !entry.children || entry.next < entry.length; });
        } else if (deadlineExceeded) cocos.status = 'skipped-time-budget';
    }

    return {
        schema: 'sdktools.web.v1',
        readOnly: true,
        viewport: viewport, dom: dom, engine: { cocos: cocos },
        coverage: {
            elapsedMs: Math.max(0, Date.now() - started),
            deadlineExceeded: deadlineExceeded,
            truncated: dom.coverage.truncated || cocos.coverage.truncated || deadlineExceeded,
            readErrorCount: errorCount,
            readErrors: errors,
            errorListTruncated: errorCount > errors.length
        },
        limits: LIMITS,
        limitations: [
            'Deadline is cooperative; synchronous page getters cannot be preempted.',
            'Only this document is traversed; iframe documents and shadow roots are not inspected.',
            'DOM rectangles do not prove pixel visibility, clipping or lack of occlusion.',
            'Cocos activity is not proof that a node is visible on screen; no texture or face data is collected.',
            'Names matching card, tile or sheep are heuristic candidates, not confirmed game objects.',
            'No hidden, inactive or fully transparent subtrees are intentionally traversed.',
            'No text, input values, credentials, cookies, storage, full URLs or network payloads are collected.'
        ]
    };
})()
