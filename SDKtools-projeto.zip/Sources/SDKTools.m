// SDKtools: explicit, local diagnostic capture for an iOS app.
// Uses public UIKit/WebKit APIs. No method swizzling or game-state writes.
#import <UIKit/UIKit.h>
#import <UIKit/UIGestureRecognizerSubclass.h>
#import <WebKit/WebKit.h>
#import <QuartzCore/QuartzCore.h>
#import <math.h>
#import <errno.h>
#import "SDKTCaptureSession.h"

static NSString *const SDKTLastArchiveKey = @"SDKtools.lastArchive.v1";
static const NSTimeInterval SDKTMaximumDuration = 300.0;

static double SDKTFinite(CGFloat value) { return isfinite(value) ? (double)value : 0.0; }
static NSDictionary *SDKTRect(CGRect rect) {
    return @{@"x": @(SDKTFinite(rect.origin.x)), @"y": @(SDKTFinite(rect.origin.y)),
             @"width": @(SDKTFinite(rect.size.width)), @"height": @(SDKTFinite(rect.size.height))};
}

@interface SDKTOverlayView : UIView
@property(nonatomic, strong) UIButton *bubble;
@property(nonatomic, strong) UIView *panel;
@end

@implementation SDKTOverlayView
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    if (self.hidden || self.alpha < 0.01 || !self.userInteractionEnabled) return nil;
    for (UIView *v in @[self.panel ?: [UIView new], self.bubble ?: [UIView new]]) {
        if (v.superview != self || v.hidden) continue;
        UIView *hit = [v hitTest:[v convertPoint:point fromView:self] withEvent:event];
        if (hit) return hit;
    }
    return nil; // The rest of the host window keeps its original hit testing.
}
@end

@interface SDKTTouchObserver : UIGestureRecognizer <UIGestureRecognizerDelegate>
@property(nonatomic, copy) void (^observe)(NSSet<UITouch *> *, UIEvent *);
@end

@implementation SDKTTouchObserver
- (instancetype)init {
    self = [super initWithTarget:nil action:NULL];
    if (self) {
        self.cancelsTouchesInView = NO;
        self.delaysTouchesBegan = NO;
        self.delaysTouchesEnded = NO;
        self.delegate = self;
    }
    return self;
}
- (BOOL)canPreventGestureRecognizer:(UIGestureRecognizer *)other { (void)other; return NO; }
- (BOOL)canBePreventedByGestureRecognizer:(UIGestureRecognizer *)other { (void)other; return NO; }
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)a shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)b {
    (void)a; (void)b; return YES;
}
- (void)finishIfNoActiveTouches:(UIEvent *)event {
    for (UITouch *touch in event.allTouches) {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled &&
            (touch.view == self.view || [touch.view isDescendantOfView:self.view])) return;
    }
    self.state = UIGestureRecognizerStateFailed; // Observe only; never recognizes a gesture.
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.observe) self.observe(touches, event);
}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.observe) self.observe(touches, event);
}
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.observe) self.observe(touches, event);
    [self finishIfNoActiveTouches:event];
}
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.observe) self.observe(touches, event);
    [self finishIfNoActiveTouches:event];
}
@end

@interface SDKToolsManager : NSObject
@property(nonatomic, strong) SDKTCaptureSession *session;
@property(nonatomic, weak) UIWindow *hostWindow;
@property(nonatomic, strong) SDKTOverlayView *overlay;
@property(nonatomic, strong) SDKTTouchObserver *touchObserver;
@property(nonatomic, strong) UILabel *statusLabel;
@property(nonatomic, strong) UILabel *detailLabel;
@property(nonatomic, strong) UIButton *startButton;
@property(nonatomic, strong) UIButton *markButton;
@property(nonatomic, strong) UIButton *stopButton;
@property(nonatomic, strong) UIButton *shareButton;
@property(nonatomic, strong) UIView *recordDot;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, strong) NSMapTable<UITouch *, NSNumber *> *touchIDs;
@property(nonatomic, strong) NSMapTable<UITouch *, NSNumber *> *lastMoves;
@property(nonatomic, strong) NSMapTable<WKWebView *, NSNumber *> *webIDs;
@property(nonatomic, strong) NSMapTable<WKWebView *, NSNumber *> *webBusySince;
@property(nonatomic, strong) NSHashTable<WKWebView *> *webTimedOut;
@property(nonatomic, copy) NSString *probeSource;
@property(nonatomic, copy) NSString *lastScreenSignature;
@property(nonatomic, strong) NSURL *lastArchive;
@property(nonatomic) NSUInteger nextTouchID;
@property(nonatomic) NSUInteger nextWebID;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) CFTimeInterval lastFrameTime;
@property(nonatomic) BOOL finalizing;
@property(nonatomic) BOOL sensitivePauseLogged;
@property(nonatomic) UIBackgroundTaskIdentifier backgroundTask;
@property(nonatomic) CGPoint dragOrigin;
@end

@implementation SDKToolsManager
+ (instancetype)shared {
    static SDKToolsManager *manager;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ manager = [SDKToolsManager new]; });
    return manager;
}
- (instancetype)init {
    self = [super init];
    if (self) {
        _session = [SDKTCaptureSession new];
        _touchIDs = [NSMapTable weakToStrongObjectsMapTable];
        _lastMoves = [NSMapTable weakToStrongObjectsMapTable];
        _webIDs = [NSMapTable weakToStrongObjectsMapTable];
        _webBusySince = [NSMapTable weakToStrongObjectsMapTable];
        _webTimedOut = [NSHashTable weakObjectsHashTable];
        _backgroundTask = UIBackgroundTaskInvalid;
    }
    return self;
}
- (void)install {
    // Scope by executable, allowing a signer to change the bundle identifier.
    NSString *executable = [NSBundle.mainBundle objectForInfoDictionaryKey:@"CFBundleExecutable"];
    if (![executable isEqualToString:@"weplay"]) return;
    NSString *bundlePath = [NSBundle.mainBundle pathForResource:@"SDKtools" ofType:@"bundle"];
    NSString *scriptPath = bundlePath ? [[NSBundle bundleWithPath:bundlePath] pathForResource:@"sdktools_probe" ofType:@"js"] : nil;
    self.probeSource = scriptPath ? [NSString stringWithContentsOfFile:scriptPath encoding:NSUTF8StringEncoding error:nil] : nil;
    NSString *saved = [NSUserDefaults.standardUserDefaults stringForKey:SDKTLastArchiveKey];
    if (saved) {
        NSURL *exports = [[NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].firstObject URLByAppendingPathComponent:@"SDKtools/Exports" isDirectory:YES];
        // Retain only a filename, so reinstall/container UUID changes do not leak paths.
        if ([saved isEqualToString:saved.lastPathComponent]) self.lastArchive = [exports URLByAppendingPathComponent:saved];
    }
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(backgrounded:) name:UIApplicationWillResignActiveNotification object:nil];
    [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(foregrounded:) name:UIApplicationDidBecomeActiveNotification object:nil];
    self.timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
    [NSRunLoop.mainRunLoop addTimer:self.timer forMode:NSRunLoopCommonModes];
    [self tick:nil];
}
- (UIWindow *)activeWindow {
    UIWindow *fallback = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) {
            if (window.hidden || window.alpha < 0.01 || window.windowLevel != UIWindowLevelNormal || !window.rootViewController) continue;
            if (window.isKeyWindow) return window;
            if (!fallback) fallback = window;
        }
    }
    return fallback;
}
- (UIButton *)menuButton:(NSString *)title action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    button.titleLabel.adjustsFontSizeToFitWidth = YES;
    button.backgroundColor = [UIColor colorWithWhite:1 alpha:0.10];
    button.layer.cornerRadius = 10;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}
- (void)attachToWindow:(UIWindow *)window {
    if (!window || self.hostWindow == window) return;
    if (self.touchObserver.view) [self.touchObserver.view removeGestureRecognizer:self.touchObserver];
    [self.overlay removeFromSuperview];
    self.hostWindow = window;
    self.overlay = [[SDKTOverlayView alloc] initWithFrame:window.bounds];
    self.overlay.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.overlay.backgroundColor = UIColor.clearColor;
    self.overlay.accessibilityIdentifier = @"SDKtools.overlay";

    UIButton *bubble = [UIButton buttonWithType:UIButtonTypeCustom];
    bubble.frame = CGRectMake(MAX(12, window.bounds.size.width - 58), MAX(12, window.bounds.size.height - window.safeAreaInsets.bottom - 100), 44, 44);
    bubble.layer.cornerRadius = 22;
    bubble.layer.borderWidth = 1;
    bubble.layer.borderColor = [UIColor colorWithRed:0.22 green:0.88 blue:0.80 alpha:0.65].CGColor;
    bubble.backgroundColor = [UIColor colorWithRed:0.05 green:0.10 blue:0.14 alpha:0.91];
    [bubble setTitle:@"SDK" forState:UIControlStateNormal];
    [bubble setTitleColor:[UIColor colorWithRed:0.40 green:0.96 blue:0.86 alpha:1] forState:UIControlStateNormal];
    bubble.titleLabel.font = [UIFont monospacedSystemFontOfSize:11 weight:UIFontWeightBold];
    bubble.accessibilityLabel = @"SDKtools. Abrir menu de captura";
    bubble.accessibilityHint = @"Arraste para mudar de canto";
    [bubble addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    UIPanGestureRecognizer *drag = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragBubble:)];
    [bubble addGestureRecognizer:drag];
    self.overlay.bubble = bubble;
    [self.overlay addSubview:bubble];
    self.recordDot = [[UIView alloc] initWithFrame:CGRectMake(33, 1, 9, 9)];
    self.recordDot.backgroundColor = UIColor.systemRedColor;
    self.recordDot.userInteractionEnabled = NO;
    self.recordDot.layer.cornerRadius = 4.5;
    [bubble addSubview:self.recordDot];

    UIView *panel = [UIView new];
    panel.backgroundColor = [UIColor colorWithRed:0.035 green:0.065 blue:0.09 alpha:0.98];
    panel.layer.cornerRadius = 18;
    panel.layer.borderWidth = 1;
    panel.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.15].CGColor;
    panel.hidden = YES;
    self.overlay.panel = panel;
    [self.overlay addSubview:panel];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(16, 14, 210, 26)];
    title.text = @"SDKtools";
    title.textColor = UIColor.whiteColor;
    title.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBold];
    [panel addSubview:title];
    UIButton *close = [UIButton buttonWithType:UIButtonTypeSystem];
    close.tag = 900;
    [close setTitle:@"×" forState:UIControlStateNormal];
    close.titleLabel.font = [UIFont systemFontOfSize:26];
    [close setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    close.accessibilityLabel = @"Fechar SDKtools";
    [close addTarget:self action:@selector(togglePanel) forControlEvents:UIControlEventTouchUpInside];
    [panel addSubview:close];
    self.statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 43, 290, 23)];
    self.statusLabel.textColor = UIColor.systemTealColor;
    self.statusLabel.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightMedium];
    [panel addSubview:self.statusLabel];
    self.detailLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 69, 290, 54)];
    self.detailLabel.text = @"Imagens, telas e toques • somente neste app.\nPode incluir conteúdo pessoal visível.\nSem áudio. Limite de 5 minutos.";
    self.detailLabel.textColor = [UIColor colorWithWhite:0.80 alpha:1];
    self.detailLabel.font = [UIFont systemFontOfSize:11];
    self.detailLabel.numberOfLines = 3;
    [panel addSubview:self.detailLabel];
    self.startButton = [self menuButton:@"Iniciar captura" action:@selector(startCapture)];
    self.markButton = [self menuButton:@"Marcar: entrei no Crazy Alpaca" action:@selector(markGame)];
    self.stopButton = [self menuButton:@"Parar e exportar ZIP" action:@selector(stopCapture)];
    self.shareButton = [self menuButton:@"Compartilhar última captura" action:@selector(shareLastArchive)];
    NSArray *buttons = @[self.startButton, self.markButton, self.stopButton, self.shareButton];
    for (NSUInteger i = 0; i < buttons.count; i++) {
        UIButton *button = buttons[i];
        button.tag = 910 + i;
        [panel addSubview:button];
    }
    [window addSubview:self.overlay];
    [self layoutPanel];

    self.touchObserver = [SDKTTouchObserver new];
    __weak typeof(self) weakSelf = self;
    self.touchObserver.observe = ^(NSSet<UITouch *> *touches, UIEvent *event) { [weakSelf observeTouches:touches event:event]; };
    [window addGestureRecognizer:self.touchObserver];
    [self updateStatus];
}
- (void)layoutPanel {
    CGRect bounds = self.overlay.bounds;
    UIEdgeInsets safe = self.hostWindow.safeAreaInsets;
    CGFloat width = MIN(330, bounds.size.width - safe.left - safe.right - 24);
    CGFloat height = MIN(342, bounds.size.height - safe.top - safe.bottom - 24);
    CGFloat x = self.overlay.bubble.center.x > bounds.size.width/2 ? bounds.size.width - safe.right - width - 12 : safe.left + 12;
    CGFloat y = MAX(safe.top + 12, MIN(self.overlay.bubble.frame.origin.y - height - 12, bounds.size.height - safe.bottom - height - 12));
    self.overlay.panel.frame = CGRectMake(x, y, width, height);
    [self.overlay.panel viewWithTag:900].frame = CGRectMake(width-48, 6, 44, 44);
    self.statusLabel.frame = CGRectMake(16, 43, width-32, 23);
    self.detailLabel.frame = CGRectMake(16, 69, width-32, 54);
    CGFloat gap = 8, available = MAX(160, height - 138), row = (available - 3*gap)/4;
    for (NSUInteger i = 0; i < 4; i++) [self.overlay.panel viewWithTag:910+i].frame = CGRectMake(14, 130+i*(row+gap), width-28, row);
}
- (void)clampBubble {
    UIEdgeInsets insets = self.hostWindow.safeAreaInsets;
    CGRect bounds = self.overlay.bounds;
    CGPoint center = self.overlay.bubble.center;
    center.x = MAX(insets.left+30, MIN(center.x, bounds.size.width-insets.right-30));
    center.y = MAX(insets.top+30, MIN(center.y, bounds.size.height-insets.bottom-30));
    self.overlay.bubble.center = center;
}
- (void)dragBubble:(UIPanGestureRecognizer *)pan {
    if (pan.state == UIGestureRecognizerStateBegan) self.dragOrigin = self.overlay.bubble.center;
    CGPoint delta = [pan translationInView:self.overlay];
    self.overlay.bubble.center = CGPointMake(self.dragOrigin.x+delta.x, self.dragOrigin.y+delta.y);
    [self clampBubble];
    if (pan.state == UIGestureRecognizerStateEnded || pan.state == UIGestureRecognizerStateCancelled) {
        CGPoint center = self.overlay.bubble.center;
        UIEdgeInsets safe = self.hostWindow.safeAreaInsets;
        center.x = center.x < self.overlay.bounds.size.width/2 ? safe.left+30 : self.overlay.bounds.size.width-safe.right-30;
        [UIView animateWithDuration:0.18 animations:^{ self.overlay.bubble.center = center; [self layoutPanel]; }];
    } else [self layoutPanel];
}
- (void)togglePanel {
    self.overlay.panel.hidden = !self.overlay.panel.hidden;
    [self layoutPanel]; [self updateStatus];
}
- (void)updateStatus {
    BOOL recording = self.session.recording;
    self.recordDot.hidden = !recording;
    self.overlay.bubble.alpha = recording || !self.overlay.panel.hidden ? 1.0 : 0.62;
    self.startButton.enabled = !recording && !self.finalizing;
    self.markButton.enabled = recording;
    self.stopButton.enabled = recording && !self.finalizing;
    self.shareButton.enabled = !recording && !self.finalizing && self.lastArchive && [NSFileManager.defaultManager fileExistsAtPath:self.lastArchive.path];
    for (UIButton *button in @[self.startButton, self.markButton, self.stopButton, self.shareButton]) button.alpha = button.enabled ? 1.0 : 0.35;
    if (self.finalizing) self.statusLabel.text = @"Finalizando arquivo…";
    else if (recording) {
        NSUInteger seconds = (NSUInteger)(self.session.elapsedMilliseconds/1000.0);
        self.statusLabel.text = [NSString stringWithFormat:@"● CAPTURANDO  %02lu:%02lu  • %lu eventos", (unsigned long)(seconds/60), (unsigned long)(seconds%60), (unsigned long)self.session.eventCount];
    }
    else self.statusLabel.text = @"LOCAL • captura parada";
}
- (void)showMessage:(NSString *)message {
    UIViewController *presenter = [self presenter];
    if (!presenter || [presenter isKindOfClass:UIAlertController.class]) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"SDKtools" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [presenter presentViewController:alert animated:YES completion:nil];
}
- (UIViewController *)presenter {
    UIViewController *vc = self.hostWindow.rootViewController;
    for (NSUInteger i=0; i<32 && vc; i++) {
        if (vc.presentedViewController && !vc.presentedViewController.isBeingDismissed) vc = vc.presentedViewController;
        else if ([vc isKindOfClass:UINavigationController.class]) {
            UIViewController *next = ((UINavigationController *)vc).visibleViewController;
            if (!next || next == vc) break; vc = next;
        } else if ([vc isKindOfClass:UITabBarController.class]) {
            UIViewController *next = ((UITabBarController *)vc).selectedViewController;
            if (!next || next == vc) break; vc = next;
        } else break;
    }
    return vc;
}
- (void)startCapture {
    if (self.finalizing || self.session.recording) return;
    NSError *error = nil;
    NSDictionary *options = @{@"mode": @"image_timeline", @"periodic_frame_interval_ms": @1000,
       @"touch_frame_min_interval_ms": @500, @"duration_limit_ms": @300000,
       @"audio": @NO, @"upload": @NO, @"web_probe": @(self.probeSource.length>0),
       @"screenshot_coverage": @"native_window_render; WebGL/video may be blank",
       @"touch_coverage": @"observed host window only; no OS keyboard or other apps",
       @"element_coverage": @"visible native views and available page/Cocos metadata; not all cards"};
    if (![self.session startWithOptions:options error:&error]) { [self showMessage:error.localizedDescription ?: @"Não foi possível iniciar a captura."]; return; }
    self.generation++;
    self.lastFrameTime = 0;
    self.lastScreenSignature = nil;
    self.sensitivePauseLogged = NO;
    [self.touchIDs removeAllObjects]; [self.lastMoves removeAllObjects];
    [self.webBusySince removeAllObjects]; [self.webTimedOut removeAllObjects];
    self.overlay.panel.hidden = YES;
    [self.session appendEventType:@"mark" data:@{@"label": @"capture_started_by_user"}];
    [self captureTick]; [self updateStatus];
}
- (void)markGame {
    if (!self.session.recording) return;
    [self.session appendEventType:@"mark" data:@{@"label": @"entered_crazy_alpaca", @"source": @"user", @"confirmed_by_analysis": @NO}];
    self.overlay.panel.hidden = YES;
    [self captureTick];
}
- (void)stopCapture {
    if (!self.session.recording || self.finalizing) return;
    self.generation++;
    self.finalizing = YES;
    [self.session appendEventType:@"mark" data:@{@"label": @"capture_stopped"}];
    __weak typeof(self) weakSelf = self;
    [self.session stopWithCompletion:^(NSURL *archive, NSError *error) {
        SDKToolsManager *self = weakSelf;
        if (!self) return;
        self.finalizing = NO;
        if (self.backgroundTask != UIBackgroundTaskInvalid) {
            [UIApplication.sharedApplication endBackgroundTask:self.backgroundTask];
            self.backgroundTask = UIBackgroundTaskInvalid;
        }
        if (archive) {
            self.lastArchive = archive;
            [NSUserDefaults.standardUserDefaults setObject:archive.lastPathComponent forKey:SDKTLastArchiveKey];
        }
        self.overlay.panel.hidden = NO;
        [self updateStatus];
        if (error) [self showMessage:error.localizedDescription];
        else if (UIApplication.sharedApplication.applicationState == UIApplicationStateActive) [self shareLastArchive];
    }];
    [self updateStatus];
}
- (void)shareLastArchive {
    if (!self.lastArchive || self.session.recording || self.finalizing) return;
    if (![NSFileManager.defaultManager fileExistsAtPath:self.lastArchive.path]) { [self showMessage:@"A última exportação não foi encontrada."]; return; }
    UIViewController *presenter = [self presenter];
    if (!presenter || [presenter isKindOfClass:UIActivityViewController.class]) return;
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[self.lastArchive] applicationActivities:nil];
    share.popoverPresentationController.sourceView = self.overlay.bubble;
    share.popoverPresentationController.sourceRect = self.overlay.bubble.bounds;
    [presenter presentViewController:share animated:YES completion:nil];
}
- (void)backgrounded:(NSNotification *)notification {
    (void)notification;
    if (self.session.recording) {
        [self.session appendEventType:@"lifecycle" data:@{@"state": @"inactive", @"action": @"stop_capture"}];
        __weak typeof(self) weakSelf = self;
        self.backgroundTask = [UIApplication.sharedApplication beginBackgroundTaskWithName:@"SDKtools.finalize" expirationHandler:^{
            SDKToolsManager *self = weakSelf;
            if (self && self.backgroundTask != UIBackgroundTaskInvalid) {
                [UIApplication.sharedApplication endBackgroundTask:self.backgroundTask];
                self.backgroundTask = UIBackgroundTaskInvalid;
            }
        }];
        [self stopCapture];
    }
}
- (void)foregrounded:(NSNotification *)notification { (void)notification; [self tick:nil]; }
- (void)tick:(NSTimer *)timer {
    (void)timer;
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    UIWindow *window = [self activeWindow];
    [self attachToWindow:window];
    if (!self.hostWindow) return;
    [self.hostWindow bringSubviewToFront:self.overlay];
    [self clampBubble]; [self layoutPanel];
    if (self.session.recording) {
        NSError *failure = self.session.lastError;
        BOOL transientBackpressure = [failure.domain isEqualToString:SDKTCaptureErrorDomain] && failure.code == ENOBUFS;
        if (failure && !transientBackpressure) {
            [self stopCapture];
            return;
        }
        if (self.session.elapsedMilliseconds >= SDKTMaximumDuration*1000) [self stopCapture];
        else [self captureTick];
    }
    [self updateStatus];
}
- (BOOL)containsSecureEntry:(UIView *)view budget:(NSUInteger *)budget {
    if (!view || *budget == 0 || view.hidden || view.alpha < 0.01 || view == self.overlay) return NO;
    (*budget)--;
    if ([view isKindOfClass:UITextField.class] && ((UITextField *)view).secureTextEntry && view.isFirstResponder) return YES;
    if ([view isKindOfClass:UITextView.class] && ((UITextView *)view).secureTextEntry && view.isFirstResponder) return YES;
    for (UIView *child in view.subviews) if ([self containsSecureEntry:child budget:budget]) return YES;
    return NO;
}
- (BOOL)pauseForSecureInput {
    NSUInteger budget = 3000;
    BOOL pause = [self containsSecureEntry:self.hostWindow budget:&budget];
    if (pause && !self.sensitivePauseLogged) {
        [self.session appendEventType:@"lifecycle" data:@{@"state": @"capture_paused_secure_input"}];
        self.sensitivePauseLogged = YES;
    } else if (!pause && self.sensitivePauseLogged) {
        [self.session appendEventType:@"lifecycle" data:@{@"state": @"capture_resumed"}];
        self.sensitivePauseLogged = NO;
    }
    return pause;
}
- (void)captureImageIfDue {
    if (!self.session.recording || !self.hostWindow || [self pauseForSecureInput]) return;
    CFTimeInterval now = CACurrentMediaTime();
    if (now-self.lastFrameTime < 0.5) return;
    self.lastFrameTime = now;
    BOOL hidden = self.overlay.hidden;
    self.overlay.hidden = YES;
    [self.session captureWindow:self.hostWindow];
    self.overlay.hidden = hidden;
}
- (void)collectController:(UIViewController *)controller into:(NSMutableArray *)names budget:(NSUInteger *)budget {
    if (!controller || !*budget) return;
    (*budget)--;
    [names addObject:NSStringFromClass(controller.class)];
    for (UIViewController *child in controller.childViewControllers) {
        if (!*budget) break;
        if (child.isViewLoaded && child.view.window && !child.view.hidden) [self collectController:child into:names budget:budget];
    }
    if (controller.presentedViewController) [self collectController:controller.presentedViewController into:names budget:budget];
}
- (void)collectView:(UIView *)view parent:(NSInteger)parent nodes:(NSMutableArray *)nodes webViews:(NSMutableArray *)webViews budget:(NSUInteger *)budget {
    if (!view || !*budget || view == self.overlay || view.hidden || view.alpha < 0.01) return;
    (*budget)--;
    CGRect rect = [view convertRect:view.bounds toView:self.hostWindow];
    if (!CGRectIntersectsRect(rect, self.hostWindow.bounds)) return;
    NSInteger index = (NSInteger)nodes.count;
    [nodes addObject:@{@"id": @(index), @"parent": @(parent), @"class": NSStringFromClass(view.class), @"frame": SDKTRect(rect), @"interactive": @(view.userInteractionEnabled)}];
    if ([view isKindOfClass:WKWebView.class]) {
        [webViews addObject:view];
        return; // Probe its page separately; avoid dumping internal WebKit views.
    }
    for (UIView *child in view.subviews) {
        if (!*budget) break;
        [self collectView:child parent:index nodes:nodes webViews:webViews budget:budget];
    }
}
- (void)captureTick {
    if (!self.session.recording || !self.hostWindow || [self pauseForSecureInput]) return;
    [self captureImageIfDue];
    NSMutableArray *controllers = [NSMutableArray new];
    NSUInteger controllerBudget = 32;
    [self collectController:self.hostWindow.rootViewController into:controllers budget:&controllerBudget];
    NSMutableArray *views = [NSMutableArray new], *webViews = [NSMutableArray new];
    NSUInteger viewBudget = 400;
    [self collectView:self.hostWindow parent:-1 nodes:views webViews:webViews budget:&viewBudget];
    NSString *signature = [controllers componentsJoinedByString:@"|"];
    BOOL changed = ![signature isEqualToString:self.lastScreenSignature];
    self.lastScreenSignature = signature;
    [self.session appendEventType:@"screen" data:@{
        @"controllers": controllers, @"controller_path_changed": @(changed), @"views": views,
        @"coordinate_space": @"window_points", @"window_bounds": SDKTRect(self.hostWindow.bounds),
        @"screen_scale": @(self.hostWindow.screen.scale), @"truncated": @(viewBudget == 0 || controllerBudget == 0),
        @"occlusion_tested": @NO, @"text_and_input_values_included": @NO}];
    NSUInteger probes = 0;
    for (WKWebView *webView in webViews) {
        if (++probes > 2) break;
        [self probeWebView:webView];
    }
}
- (void)probeWebView:(WKWebView *)webView {
    if (!self.probeSource.length || [self.webTimedOut containsObject:webView]) return;
    NSNumber *pending = [self.webBusySince objectForKey:webView];
    if (pending) {
        if (CACurrentMediaTime() - pending.doubleValue > 5.0) {
            [self.webTimedOut addObject:webView];
            [self.session appendEventType:@"error" data:@{@"component": @"web_probe", @"code": @"timed_out", @"retry": @"next_session"}];
        }
        return;
    }
    NSNumber *identifier = [self.webIDs objectForKey:webView];
    if (!identifier) { identifier = @(++self.nextWebID); [self.webIDs setObject:identifier forKey:webView]; }
    [self.webBusySince setObject:@(CACurrentMediaTime()) forKey:webView];
    NSUInteger generation = self.generation;
    double requestMilliseconds = self.session.elapsedMilliseconds;
    NSDictionary *frame = SDKTRect([webView convertRect:webView.bounds toView:self.hostWindow]);
    __weak typeof(self) weakSelf = self;
    __weak WKWebView *weakWeb = webView;
    [webView evaluateJavaScript:self.probeSource completionHandler:^(id result, NSError *error) {
        SDKToolsManager *self = weakSelf;
        WKWebView *web = weakWeb;
        if (!self || !web) return;
        if (generation != self.generation || !self.session.recording) return;
        [self.webBusySince removeObjectForKey:web];
        if ([self.webTimedOut containsObject:web]) return;
        if (error) {
            // Avoid exception messages that might contain page data or URLs.
            [self.session appendEventType:@"error" data:@{@"component": @"web_probe", @"web_id": identifier, @"domain": error.domain ?: @"", @"code": @(error.code)}];
        } else if ([result isKindOfClass:NSDictionary.class] && [NSJSONSerialization isValidJSONObject:result]) {
            [self.session appendEventType:@"web_snapshot" data:@{@"web_id": identifier, @"frame_in_window_points": frame, @"request_elapsed_ms": @(requestMilliseconds), @"completion_elapsed_ms": @(self.session.elapsedMilliseconds), @"snapshot": result}];
        } else [self.session appendEventType:@"error" data:@{@"component": @"web_probe", @"code": @"non_json_result"}];
    }];
}
- (void)observeTouches:(NSSet<UITouch *> *)touches event:(UIEvent *)event {
    (void)event;
    if (!self.session.recording || self.finalizing || [self pauseForSecureInput]) return;
    for (UITouch *touch in touches) {
        if (!touch.view || touch.view == self.overlay || [touch.view isDescendantOfView:self.overlay]) continue;
        if (touch.phase == UITouchPhaseStationary || touch.phase == UITouchPhaseRegionEntered || touch.phase == UITouchPhaseRegionMoved || touch.phase == UITouchPhaseRegionExited) continue;
        NSNumber *identifier = [self.touchIDs objectForKey:touch];
        if (!identifier) { identifier = @(++self.nextTouchID); [self.touchIDs setObject:identifier forKey:touch]; }
        if (touch.phase == UITouchPhaseMoved) {
            NSNumber *last = [self.lastMoves objectForKey:touch];
            if (last && touch.timestamp-last.doubleValue < 1.0/20.0) continue;
            [self.lastMoves setObject:@(touch.timestamp) forKey:touch];
        }
        CGPoint point = [touch locationInView:self.hostWindow];
        NSString *phase = @"unknown";
        switch(touch.phase) {
            case UITouchPhaseBegan: phase=@"began"; break;
            case UITouchPhaseMoved: phase=@"moved"; break;
            case UITouchPhaseEnded: phase=@"ended"; break;
            case UITouchPhaseCancelled: phase=@"cancelled"; break;
            default: break;
        }
        CGSize size = self.hostWindow.bounds.size;
        [self.session appendEventType:@"touch" data:@{
            @"touch_id": identifier, @"phase": phase, @"x": @(SDKTFinite(point.x)), @"y": @(SDKTFinite(point.y)),
            @"normalized_x": @(SDKTFinite(point.x/MAX(1,size.width))), @"normalized_y": @(SDKTFinite(point.y/MAX(1,size.height))),
            @"coordinate_space": @"window_points", @"target_class": NSStringFromClass(touch.view.class),
            @"tap_count": @(touch.tapCount), @"touch_type": @(touch.type)}];
        if (touch.phase == UITouchPhaseEnded || touch.phase == UITouchPhaseCancelled) {
            [self.touchIDs removeObjectForKey:touch]; [self.lastMoves removeObjectForKey:touch];
            NSUInteger generation = self.generation;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 150*NSEC_PER_MSEC), dispatch_get_main_queue(), ^{
                if (generation == self.generation) [self captureImageIfDue];
            });
        }
    }
}
@end

__attribute__((constructor)) static void SDKTLoad(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2*NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        @autoreleasepool { [[SDKToolsManager shared] install]; }
    });
}
