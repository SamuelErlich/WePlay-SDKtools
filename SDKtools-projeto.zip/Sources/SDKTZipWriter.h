#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Writes a standard stored ZIP (CRC-32, UTF-8 names). No processes or network.
/// Includes only session.json and regular JPEG files below frames/.
@interface SDKTZipWriter : NSObject
+ (BOOL)archiveDirectory:(NSURL *)directory
                  toURL:(NSURL *)destination
                  error:(NSError * _Nullable * _Nullable)error;
@end

NS_ASSUME_NONNULL_END
