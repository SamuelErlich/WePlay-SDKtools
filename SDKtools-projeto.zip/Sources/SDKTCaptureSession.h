#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSErrorDomain const SDKTCaptureErrorDomain;

/// Explicit, local-only session recorder. Call all public methods on the main queue.
/// Screenshots describe visible UIKit output; they do not prove WebGL content was rendered.
@interface SDKTCaptureSession : NSObject
@property (nonatomic, readonly, getter=isRecording) BOOL recording;
@property (nonatomic, readonly) NSUInteger eventCount;
@property (nonatomic, readonly) NSTimeInterval elapsedMilliseconds;
@property (nonatomic, readonly, nullable) NSURL *directoryURL;
@property (nonatomic, readonly, nullable) NSError *lastError;

- (BOOL)startWithOptions:(NSDictionary *)options error:(NSError * _Nullable * _Nullable)error;
- (void)appendEventType:(NSString *)type data:(NSDictionary *)data;
- (void)captureWindow:(UIWindow *)window;
/// Stops accepting events immediately, drains pending writes, then completes on main.
/// The final JSON and frames remain available if ZIP creation fails.
/// A nonnull archive together with an error means a usable export with capture warnings.
- (void)stopWithCompletion:(void (^)(NSURL * _Nullable archiveURL,
                                    NSError * _Nullable error))completion;
@end

NS_ASSUME_NONNULL_END
