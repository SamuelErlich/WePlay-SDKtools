#import "SDKTCaptureSession.h"
#import "SDKTZipWriter.h"
#import <QuartzCore/QuartzCore.h>
#import <sys/stat.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>
#import <math.h>

NSErrorDomain const SDKTCaptureErrorDomain = @"SDKtools.Capture";
static const NSUInteger SDKTMaximumEvents = 60000;
static const NSUInteger SDKTMaximumEventBytes = 262144;
static const NSUInteger SDKTMaximumQueuedEventBytes = 4 * 1024 * 1024;
static const uint64_t SDKTMaximumSessionBytes = 250ULL * 1024ULL * 1024ULL;
static const uint64_t SDKTMaximumManifestBytes = 64ULL * 1024ULL * 1024ULL;
static const uint64_t SDKTManifestReserveBytes = 65536;

static NSError *SDKTError(NSInteger code, NSString *description) {
    return [NSError errorWithDomain:SDKTCaptureErrorDomain code:code
                          userInfo:@{NSLocalizedDescriptionKey: description}];
}

static BOOL SDKTWriteAll(int descriptor, const void *bytes, size_t length, NSError **error) {
    const uint8_t *cursor = bytes;
    while (length > 0) {
        ssize_t count = write(descriptor, cursor, length);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) {
            if (error) *error = SDKTError(errno ?: EIO, @"Could not write capture data to disk.");
            return NO;
        }
        cursor += count;
        length -= (size_t)count;
    }
    return YES;
}

static BOOL SDKTWriteData(int descriptor, NSData *data, NSError **error) {
    return SDKTWriteAll(descriptor, data.bytes, data.length, error);
}

static NSData * _Nullable SDKTJSONData(id value, NSError **error) {
    if (![NSJSONSerialization isValidJSONObject:value]) {
        if (error) *error = SDKTError(EINVAL, @"An event contains non-JSON values or non-finite numbers.");
        return nil;
    }
    return [NSJSONSerialization dataWithJSONObject:value options:0 error:error];
}

@interface SDKTCaptureSession () {
    dispatch_queue_t _writerQueue;
    int _journalFD;
    BOOL _finalizing;
    BOOL _capturePending;
    BOOL _writerHalted;
    NSUInteger _generation;
    NSUInteger _nextFrame;
    NSUInteger _capturesRequested;
    NSUInteger _capturesDropped;
    NSUInteger _framesWritten;
    NSUInteger _framesFailed;
    NSUInteger _eventsWritten;
    NSUInteger _eventsDropped;
    NSUInteger _queuedEventBytes;
    uint64_t _diskBytes;
    uint64_t _journalBytes;
    CFTimeInterval _startedMonotonic;
    NSTimeInterval _finalDurationMilliseconds;
    NSString *_sessionIdentifier;
    NSString *_startedAt;
    NSDictionary *_appInfo;
    NSDictionary *_captureConfig;
    NSError *_writerError;
    NSURL *_journalURL;
    NSURL *_exportsURL;
}
@property (nonatomic, readwrite, getter=isRecording) BOOL recording;
@property (nonatomic, readwrite) NSUInteger eventCount;
@property (nonatomic, readwrite, nullable) NSURL *directoryURL;
@property (nonatomic, readwrite, nullable) NSError *lastError;
@end

@implementation SDKTCaptureSession

- (instancetype)init {
    if ((self = [super init])) {
        _writerQueue = dispatch_queue_create("SDKtools.capture.writer", DISPATCH_QUEUE_SERIAL);
        _journalFD = -1;
    }
    return self;
}

- (void)dealloc {
    if (_journalFD >= 0) close(_journalFD);
}

- (NSTimeInterval)elapsedMilliseconds {
    NSTimeInterval elapsed = self.recording ? (CACurrentMediaTime() - _startedMonotonic) * 1000.0
                                            : _finalDurationMilliseconds;
    return isfinite(elapsed) ? MAX(0.0, elapsed) : 0.0;
}

- (BOOL)startWithOptions:(NSDictionary *)options error:(NSError **)error {
    NSAssert(NSThread.isMainThread, @"SDKtools session methods require the main thread.");
    if (self.recording || _finalizing) {
        NSError *failure = SDKTError(EBUSY, @"A capture is already recording or finalizing.");
        if (error) *error = failure;
        self.lastError = failure;
        return NO;
    }
    NSError *failure = nil;
    NSData *optionsData = SDKTJSONData(options, &failure);
    if (!optionsData || optionsData.length > 16384) {
        failure = failure ?: SDKTError(EFBIG, @"Capture options exceed the 16 KiB limit.");
        if (error) *error = failure;
        self.lastError = failure;
        return NO;
    }
    NSDictionary *optionsSnapshot = [NSJSONSerialization JSONObjectWithData:optionsData options:0 error:&failure];
    if (![optionsSnapshot isKindOfClass:NSDictionary.class]) {
        failure = failure ?: SDKTError(EINVAL, @"Capture options must be a JSON object.");
        if (error) *error = failure;
        self.lastError = failure;
        return NO;
    }

    NSFileManager *manager = NSFileManager.defaultManager;
    NSURL *documents = [manager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].firstObject;
    if (!documents) {
        failure = SDKTError(ENOENT, @"The app's Documents directory is unavailable.");
        if (error) *error = failure;
        self.lastError = failure;
        return NO;
    }
    NSURL *rootURL = [documents URLByAppendingPathComponent:@"SDKtools" isDirectory:YES];
    NSURL *sessionsURL = [rootURL URLByAppendingPathComponent:@"Sessions" isDirectory:YES];
    NSString *identifier = NSUUID.UUID.UUIDString.lowercaseString;
    NSURL *sessionURL = [sessionsURL URLByAppendingPathComponent:identifier isDirectory:YES];
    NSURL *framesURL = [sessionURL URLByAppendingPathComponent:@"frames" isDirectory:YES];
    NSDictionary *attributes = @{NSFileProtectionKey: NSFileProtectionCompleteUntilFirstUserAuthentication};
    if (![manager createDirectoryAtURL:framesURL withIntermediateDirectories:YES attributes:attributes error:&failure] ||
        ![rootURL setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:&failure]) {
        [manager removeItemAtURL:sessionURL error:nil];
        if (error) *error = failure;
        self.lastError = failure;
        return NO;
    }
    NSURL *journalURL = [sessionURL URLByAppendingPathComponent:@"events.ndjson"];
    int descriptor = open(journalURL.fileSystemRepresentation, O_CREAT | O_EXCL | O_WRONLY | O_CLOEXEC, 0600);
    if (descriptor < 0) {
        failure = SDKTError(errno, @"Could not create the session event journal.");
        [manager removeItemAtURL:sessionURL error:nil];
        if (error) *error = failure;
        self.lastError = failure;
        return NO;
    }

    _journalFD = descriptor;
    _journalURL = journalURL;
    _exportsURL = [rootURL URLByAppendingPathComponent:@"Exports" isDirectory:YES];
    self.directoryURL = sessionURL;
    _sessionIdentifier = identifier;
    NSISO8601DateFormatter *dateFormatter = [NSISO8601DateFormatter new];
    dateFormatter.formatOptions = NSISO8601DateFormatWithInternetDateTime | NSISO8601DateFormatWithFractionalSeconds;
    _startedAt = [dateFormatter stringFromDate:NSDate.date];
    NSBundle *bundle = NSBundle.mainBundle;
    _appInfo = @{@"bundle_id": bundle.bundleIdentifier ?: @"",
                 @"version": [bundle objectForInfoDictionaryKey:@"CFBundleShortVersionString"] ?: @"",
                 @"build": [bundle objectForInfoDictionaryKey:@"CFBundleVersion"] ?: @""};
    NSMutableDictionary *config = [optionsSnapshot mutableCopy];
    config[@"maximum_events"] = @(SDKTMaximumEvents);
    config[@"maximum_session_bytes"] = @(SDKTMaximumSessionBytes);
    config[@"maximum_manifest_bytes"] = @(SDKTMaximumManifestBytes);
    config[@"screenshot_max_width_px"] = @1170;
    config[@"screenshot_max_height_px"] = @4096;
    config[@"jpeg_quality"] = @0.65;
    config[@"screenshot_renderer"] = @"UIKit.drawViewHierarchyInRect";
    config[@"screenshot_limitations"] = @[@"WebGL, protected, and compositor-backed content may be missing.",
                                            @"A screenshot contains visible pixels, not hidden game state."];
    config[@"storage"] = @"local_only";
    _captureConfig = [config copy];
    _generation++;
    _capturePending = NO;
    _writerHalted = NO;
    _nextFrame = 0;
    _capturesRequested = 0;
    _capturesDropped = 0;
    _framesWritten = 0;
    _framesFailed = 0;
    _eventsWritten = 0;
    _eventsDropped = 0;
    _queuedEventBytes = 0;
    _diskBytes = 0;
    _journalBytes = 0;
    _writerError = nil;
    self.lastError = nil;
    self.eventCount = 0;
    _finalDurationMilliseconds = 0;
    _startedMonotonic = CACurrentMediaTime();
    self.recording = YES;
    [self appendEventType:@"session_start" data:@{}];
    return YES;
}

- (void)recordWriterError:(NSError *)error halt:(BOOL)halt {
    if (!_writerError) _writerError = error;
    if (halt) _writerHalted = YES;
    NSUInteger generation = _generation;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (generation == self->_generation) self.lastError = error;
    });
}

- (BOOL)hasBudgetForBytes:(uint64_t)bytes additionalJournalBytes:(uint64_t)journalBytes {
    // Reserve room for streaming session.json while events.ndjson still exists.
    return bytes <= SDKTMaximumSessionBytes &&
           _diskBytes + bytes + _journalBytes + journalBytes +
               SDKTManifestReserveBytes + SDKTMaximumEvents <= SDKTMaximumSessionBytes;
}

- (void)writeEventData:(NSData *)data {
    if (_writerHalted || _journalFD < 0) return;
    uint64_t length = (uint64_t)data.length + 1;
    if (_journalBytes + length + SDKTManifestReserveBytes + SDKTMaximumEvents > SDKTMaximumManifestBytes) {
        [self recordWriterError:SDKTError(EFBIG, @"The 64 MiB event manifest limit was reached; later events were omitted.") halt:YES];
        return;
    }
    if (![self hasBudgetForBytes:length additionalJournalBytes:length]) {
        [self recordWriterError:SDKTError(EFBIG, @"The 250 MiB session limit was reached; later events were omitted.") halt:YES];
        return;
    }
    NSError *error = nil;
    const uint8_t newline = '\n';
    if (!SDKTWriteData(_journalFD, data, &error) || !SDKTWriteAll(_journalFD, &newline, 1, &error)) {
        [self recordWriterError:error halt:YES];
        return;
    }
    _diskBytes += length;
    _journalBytes += length;
    _eventsWritten++;
}

- (void)appendEventType:(NSString *)type data:(NSDictionary *)data {
    NSAssert(NSThread.isMainThread, @"SDKtools session methods require the main thread.");
    if (!self.recording) return;
    if (self.eventCount >= SDKTMaximumEvents) {
        _eventsDropped++;
        self.lastError = SDKTError(EFBIG, @"The 60,000 event limit was reached; later events were omitted.");
        return;
    }
    if (![type isKindOfClass:NSString.class] || type.length == 0 || type.length > 128 ||
        ![data isKindOfClass:NSDictionary.class]) {
        _eventsDropped++;
        self.lastError = SDKTError(EINVAL, @"Events require a short type name and a JSON data object.");
        return;
    }
    NSDictionary *event = @{@"seq": @(self.eventCount + 1), @"type": type,
                            @"t_ms": @(self.elapsedMilliseconds), @"data": data};
    NSError *error = nil;
    NSData *encoded = SDKTJSONData(event, &error);
    if (!encoded || encoded.length > SDKTMaximumEventBytes) {
        _eventsDropped++;
        self.lastError = error ?: SDKTError(EFBIG, @"An event exceeds the 256 KiB limit and was omitted.");
        return;
    }
    if (_queuedEventBytes + encoded.length > SDKTMaximumQueuedEventBytes) {
        _eventsDropped++;
        self.lastError = SDKTError(ENOBUFS, @"The event writer is busy; an event was omitted to bound memory use.");
        return;
    }
    self.eventCount++;
    _queuedEventBytes += encoded.length;
    NSUInteger generation = _generation;
    dispatch_async(_writerQueue, ^{
        @autoreleasepool {
            [self writeEventData:encoded];
            dispatch_async(dispatch_get_main_queue(), ^{
                if (generation == self->_generation) self->_queuedEventBytes -= encoded.length;
            });
        }
    });
}

- (void)captureWindow:(UIWindow *)window {
    NSAssert(NSThread.isMainThread, @"SDKtools session methods require the main thread.");
    if (!self.recording) return;
    _capturesRequested++;
    if (_capturePending) { _capturesDropped++; return; }
    if (self.eventCount >= SDKTMaximumEvents) {
        _capturesDropped++;
        self.lastError = SDKTError(EFBIG, @"The event limit prevents further screenshots.");
        return;
    }
    if (!window || window.hidden || !isfinite(window.bounds.size.width) ||
        !isfinite(window.bounds.size.height) || window.bounds.size.width <= 0 || window.bounds.size.height <= 0) {
        _capturesDropped++;
        [self appendEventType:@"screenshot" data:@{@"status": @"no_visible_window",
                                                   @"renderer": @"UIKit.drawViewHierarchyInRect"}];
        return;
    }
    CGSize pointSize = window.bounds.size;
    CGFloat nativeScale = window.screen.scale;
    if (!isfinite(nativeScale) || nativeScale <= 0) nativeScale = 1.0;
    CGFloat imageScale = MIN(nativeScale, MIN(1170.0 / pointSize.width, 4096.0 / pointSize.height));
    CGFloat pixelWidth = pointSize.width * imageScale;
    CGFloat outputHeight = pointSize.height * imageScale;
    if (!isfinite(imageScale) || imageScale <= 0 || !isfinite(pixelWidth) || !isfinite(outputHeight) ||
        pixelWidth < 1.0 || outputHeight < 1.0 || pixelWidth > 1170.01 || outputHeight > 4096.01) {
        _capturesDropped++;
        [self appendEventType:@"screenshot" data:@{@"status": @"unsupported_window_dimensions",
                                                   @"renderer": @"UIKit.drawViewHierarchyInRect"}];
        return;
    }
    _capturePending = YES;
    NSUInteger generation = _generation;
    NSUInteger frameIndex = ++_nextFrame;
    NSUInteger sequence = ++self.eventCount;
    NSTimeInterval timestamp = self.elapsedMilliseconds;
    UIGraphicsImageRendererFormat *format = [UIGraphicsImageRendererFormat defaultFormat];
    format.scale = imageScale;
    format.opaque = YES;
    format.preferredRange = UIGraphicsImageRendererFormatRangeStandard;
    __block BOOL rendered = NO;
    UIImage *image = nil;
    NSString *renderFailure = nil;
    @try {
        UIGraphicsImageRenderer *renderer = [[UIGraphicsImageRenderer alloc] initWithSize:pointSize format:format];
        image = [renderer imageWithActions:^(UIGraphicsImageRendererContext *context) {
            [UIColor.blackColor setFill];
            UIRectFill((CGRect){CGPointZero, pointSize});
            rendered = [window drawViewHierarchyInRect:(CGRect){CGPointZero, pointSize} afterScreenUpdates:NO];
        }];
    } @catch (NSException *exception) {
        // Do not export exception text: it may contain arbitrary app data.
        renderFailure = @"UIKit could not render the window.";
    }
    NSUInteger pixelHeight = image.CGImage ? CGImageGetHeight(image.CGImage) : (NSUInteger)llround(outputHeight);
    NSUInteger actualWidth = image.CGImage ? CGImageGetWidth(image.CGImage) : (NSUInteger)llround(pixelWidth);
    NSString *relativePath = [NSString stringWithFormat:@"frames/frame_%06lu.jpg", (unsigned long)frameIndex];
    NSURL *imageURL = [self.directoryURL URLByAppendingPathComponent:relativePath];

    dispatch_async(_writerQueue, ^{
        @autoreleasepool {
            NSMutableDictionary *capture = [@{@"width_px": @(actualWidth), @"height_px": @(pixelHeight),
                @"window_width_points": @(pointSize.width), @"window_height_points": @(pointSize.height),
                @"renderer": @"UIKit.drawViewHierarchyInRect", @"draw_succeeded": @(rendered),
                @"webgl_content_not_guaranteed": @YES} mutableCopy];
            NSError *error = nil;
            NSData *jpeg = nil;
            if (!self->_writerHalted && image && rendered && !renderFailure) {
                jpeg = UIImageJPEGRepresentation(image, 0.65);
            }
            if (self->_writerHalted) {
                capture[@"status"] = @"writer_stopped";
                self->_framesFailed++;
            } else if (!jpeg.length) {
                capture[@"status"] = @"renderer_failed";
                capture[@"message"] = renderFailure ?: @"UIKit returned no usable capture; WebGL content may be unavailable.";
                self->_framesFailed++;
            } else if (![self hasBudgetForBytes:jpeg.length + 4096 additionalJournalBytes:4096]) {
                capture[@"status"] = @"disk_limit";
                self->_framesFailed++;
                [self recordWriterError:SDKTError(EFBIG, @"A screenshot was omitted at the session storage limit.") halt:NO];
            } else if (![jpeg writeToURL:imageURL options:NSDataWritingAtomic | NSDataWritingFileProtectionCompleteUntilFirstUserAuthentication error:&error]) {
                capture[@"status"] = @"write_failed";
                self->_framesFailed++;
                [self recordWriterError:error halt:NO];
            } else {
                capture[@"status"] = @"captured";
                capture[@"file"] = relativePath;
                capture[@"bytes"] = @(jpeg.length);
                self->_diskBytes += jpeg.length;
                self->_framesWritten++;
            }
            NSDictionary *event = @{@"seq": @(sequence), @"type": @"screenshot", @"t_ms": @(timestamp), @"data": capture};
            NSData *eventJSON = SDKTJSONData(event, &error);
            if (eventJSON) [self writeEventData:eventJSON];
            else [self recordWriterError:error halt:YES];
            dispatch_async(dispatch_get_main_queue(), ^{
                if (generation == self->_generation) self->_capturePending = NO;
            });
        }
    });
}

- (BOOL)finalizeManifest:(NSDictionary *)metadata error:(NSError **)error {
    NSData *header = SDKTJSONData(metadata, error);
    if (!header.length) return NO;
    if (header.length > SDKTManifestReserveBytes) {
        if (error) *error = SDKTError(EFBIG, @"Session metadata exceeds its reserved storage budget.");
        return NO;
    }
    NSURL *targetURL = [self.directoryURL URLByAppendingPathComponent:@"session.json"];
    NSURL *partialURL = [self.directoryURL URLByAppendingPathComponent:@"session.json.partial"];
    int output = open(partialURL.fileSystemRepresentation, O_CREAT | O_EXCL | O_WRONLY | O_CLOEXEC, 0600);
    if (output < 0) {
        if (error) *error = SDKTError(errno, @"Could not create the final session manifest.");
        return NO;
    }
    BOOL success = SDKTWriteAll(output, header.bytes, header.length - 1, error);
    if (success) success = SDKTWriteData(output, [@",\"events\":[\n" dataUsingEncoding:NSUTF8StringEncoding], error);
    NSInputStream *stream = [NSInputStream inputStreamWithURL:_journalURL];
    [stream open];
    NSMutableData *pending = [NSMutableData data];
    NSUInteger emitted = 0;
    uint8_t buffer[65536];
    while (success) {
        NSInteger readCount = [stream read:buffer maxLength:sizeof(buffer)];
        if (readCount < 0) {
            if (error) *error = stream.streamError ?: SDKTError(EIO, @"Could not read the event journal.");
            success = NO;
            break;
        }
        if (readCount == 0) break;
        [pending appendBytes:buffer length:(NSUInteger)readCount];
        const uint8_t *bytes = pending.bytes;
        NSUInteger consumed = 0;
        for (NSUInteger index = 0; index < pending.length; index++) {
            if (bytes[index] != '\n') continue;
            @autoreleasepool {
                NSUInteger length = index - consumed;
                if (!length || length > SDKTMaximumEventBytes || emitted >= self->_eventsWritten) {
                    if (error) *error = SDKTError(EINVAL, @"The event journal contains an unexpected record.");
                    success = NO;
                    break;
                }
                if (emitted) success = SDKTWriteAll(output, ",\n", 2, error);
                if (success) success = SDKTWriteAll(output, bytes + consumed, length, error);
                if (!success) break;
                emitted++;
                consumed = index + 1;
            }
        }
        if (!success) break;
        if (consumed) [pending replaceBytesInRange:NSMakeRange(0, consumed) withBytes:NULL length:0];
        if (pending.length > SDKTMaximumEventBytes) {
            if (error) *error = SDKTError(EFBIG, @"An event journal record exceeds the supported size.");
            success = NO;
        }
    }
    [stream close];
    // A failed write can leave one incomplete tail. Only fully committed records count.
    if (success && emitted != _eventsWritten) {
        if (error) *error = SDKTError(EIO, @"The event journal is incomplete; raw capture files were preserved.");
        success = NO;
    }
    if (success && pending.length > 0 && !_writerHalted) {
        if (error) *error = SDKTError(EIO, @"The event journal has an unexpected incomplete tail.");
        success = NO;
    }
    if (success) success = SDKTWriteAll(output, "\n]}\n", 4, error);
    if (success && fsync(output) != 0) {
        if (error) *error = SDKTError(errno, @"Could not synchronize the finalized session.");
        success = NO;
    }
    if (close(output) != 0 && success) {
        if (error) *error = SDKTError(errno, @"Could not close the finalized session.");
        success = NO;
    }
    if (success) success = [NSFileManager.defaultManager moveItemAtURL:partialURL toURL:targetURL error:error];
    if (!success) [NSFileManager.defaultManager removeItemAtURL:partialURL error:nil];
    return success;
}

- (void)stopWithCompletion:(void (^)(NSURL * _Nullable, NSError * _Nullable))completion {
    NSAssert(NSThread.isMainThread, @"SDKtools session methods require the main thread.");
    if (!self.recording || _finalizing) {
        NSError *error = SDKTError(_finalizing ? EBUSY : EINVAL,
            _finalizing ? @"This session is already finalizing." : @"There is no active capture to stop.");
        self.lastError = error;
        dispatch_async(dispatch_get_main_queue(), ^{ completion(nil, error); });
        return;
    }
    [self appendEventType:@"session_stop" data:@{}];
    _finalDurationMilliseconds = self.elapsedMilliseconds;
    self.recording = NO;
    _finalizing = YES;
    NSUInteger requested = _capturesRequested;
    NSUInteger dropped = _capturesDropped;
    NSUInteger acceptedEvents = self.eventCount;
    NSUInteger droppedEvents = _eventsDropped;
    NSTimeInterval duration = _finalDurationMilliseconds;
    NSError *mainWarning = self.lastError;
    dispatch_async(_writerQueue, ^{
        @autoreleasepool {
            NSError *failure = nil;
            if (self->_journalFD >= 0) {
                if (fsync(self->_journalFD) != 0) {
                    [self recordWriterError:SDKTError(errno, @"Could not synchronize the event journal.") halt:YES];
                }
                if (close(self->_journalFD) != 0) {
                    [self recordWriterError:SDKTError(errno, @"Could not close the event journal.") halt:YES];
                }
                self->_journalFD = -1;
            }
            NSMutableArray<NSString *> *warnings = [NSMutableArray array];
            if (mainWarning) [warnings addObject:mainWarning.localizedDescription];
            if (self->_writerError && ![warnings containsObject:self->_writerError.localizedDescription]) {
                [warnings addObject:self->_writerError.localizedDescription];
            }
            NSUInteger unwrittenEvents = acceptedEvents - self->_eventsWritten;
            if (self->_framesFailed > 0) [warnings addObject:@"Some requested screenshots could not be rendered or written."];
            if (dropped > 0) [warnings addObject:@"Some screenshot requests were skipped while a capture was pending or unavailable."];
            NSDictionary *metadata = @{@"schema": @"sdktools.session.v1",
                @"session_id": self->_sessionIdentifier, @"started_at": self->_startedAt,
                @"duration_ms": @(duration), @"app": self->_appInfo,
                @"capture_config": self->_captureConfig, @"event_count": @(self->_eventsWritten),
                @"events_accepted": @(acceptedEvents), @"events_rejected": @(droppedEvents),
                @"events_unwritten": @(unwrittenEvents), @"events_dropped": @(droppedEvents + unwrittenEvents),
                @"warnings": warnings,
                @"capture_stats": @{@"requested": @(requested), @"dropped": @(dropped),
                                     @"written": @(self->_framesWritten), @"failed": @(self->_framesFailed)}};
            NSURL *archive = nil;
            if ([self finalizeManifest:metadata error:&failure]) {
                [NSFileManager.defaultManager removeItemAtURL:self->_journalURL error:nil];
                NSDictionary *attributes = @{NSFileProtectionKey: NSFileProtectionCompleteUntilFirstUserAuthentication};
                if ([NSFileManager.defaultManager createDirectoryAtURL:self->_exportsURL
                        withIntermediateDirectories:YES attributes:attributes error:&failure]) {
                    NSURL *archiveURL = [self->_exportsURL URLByAppendingPathComponent:
                        [self->_sessionIdentifier stringByAppendingPathExtension:@"zip"]];
                    if ([SDKTZipWriter archiveDirectory:self.directoryURL toURL:archiveURL error:&failure]) {
                        archive = archiveURL;
                        [archiveURL setResourceValue:@YES forKey:NSURLIsExcludedFromBackupKey error:nil];
                    }
                }
            }
            NSError *completionError = failure;
            if (archive && !completionError && warnings.count > 0) {
                completionError = SDKTError(1001, @"Captura exportada com avisos: alguns eventos ou imagens foram omitidos. O ZIP permanece disponível para compartilhar.");
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                self->_finalizing = NO;
                self->_capturePending = NO;
                if (completionError) self.lastError = completionError;
                completion(archive, completionError);
            });
        }
    });
}
@end
