#import "SDKTZipWriter.h"
#import <zlib.h>
#import <sys/stat.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>
#import <stdint.h>

static NSString * const SDKTZipErrorDomain = @"SDKtools.Zip";
static const uint64_t SDKTZipMaximumInputBytes = 250ULL * 1024ULL * 1024ULL;

static NSError *SDKTZipError(NSInteger code, NSString *description) {
    return [NSError errorWithDomain:SDKTZipErrorDomain code:code
                          userInfo:@{NSLocalizedDescriptionKey: description}];
}

static BOOL SDKTZipFail(NSError **error, NSInteger code, NSString *description) {
    if (error) *error = SDKTZipError(code, description);
    return NO;
}

static void SDKTLE16(NSMutableData *data, uint16_t value) {
    uint8_t bytes[] = {(uint8_t)value, (uint8_t)(value >> 8)};
    [data appendBytes:bytes length:sizeof(bytes)];
}

static void SDKTLE32(NSMutableData *data, uint32_t value) {
    uint8_t bytes[] = {(uint8_t)value, (uint8_t)(value >> 8),
                      (uint8_t)(value >> 16), (uint8_t)(value >> 24)};
    [data appendBytes:bytes length:sizeof(bytes)];
}

static BOOL SDKTWriteBytes(int fd, const void *bytes, size_t length, NSError **error) {
    const uint8_t *cursor = bytes;
    while (length) {
        ssize_t written = write(fd, cursor, length);
        if (written < 0 && errno == EINTR) continue;
        if (written <= 0) {
            return SDKTZipFail(error, errno ?: EIO, @"Could not write the ZIP file.");
        }
        cursor += written;
        length -= (size_t)written;
    }
    return YES;
}

static BOOL SDKTWriteData(int fd, NSData *data, NSError **error) {
    return SDKTWriteBytes(fd, data.bytes, data.length, error);
}

static BOOL SDKTReadCRC(int fd, uint64_t expectedLength, uint32_t *crc,
                        NSError **error) {
    uint8_t buffer[65536];
    uint64_t count = 0;
    uLong current = crc32(0L, Z_NULL, 0);
    while (YES) {
        ssize_t size = read(fd, buffer, sizeof(buffer));
        if (size < 0 && errno == EINTR) continue;
        if (size < 0) return SDKTZipFail(error, errno, @"Could not read an export file.");
        if (!size) break;
        count += (uint64_t)size;
        if (count > expectedLength) {
            return SDKTZipFail(error, EIO, @"An export file changed while archiving.");
        }
        current = crc32(current, buffer, (uInt)size);
    }
    if (count != expectedLength || lseek(fd, 0, SEEK_SET) == (off_t)-1) {
        return SDKTZipFail(error, EIO, @"An export file was incomplete or unreadable.");
    }
    *crc = (uint32_t)current;
    return YES;
}

static BOOL SDKTVerifyFrameReferences(NSURL *manifestURL, NSSet<NSString *> *names,
                                      NSError **error) {
    // The recorder writes a single metadata line, one JSON event per line, and
    // a closing array/object line. Inspect it incrementally, not as a 64 MiB tree.
    NSInputStream *stream = [NSInputStream inputStreamWithURL:manifestURL];
    [stream open];
    NSMutableData *pending = [NSMutableData data];
    uint8_t buffer[65536];
    NSUInteger lineNumber = 0;
    NSUInteger eventCount = 0;
    NSUInteger declaredEvents = NSNotFound;
    BOOL closed = NO;
    BOOL success = YES;
    while (success) {
        NSInteger readCount = [stream read:buffer maxLength:sizeof(buffer)];
        if (readCount < 0) {
            if (error) *error = stream.streamError ?: SDKTZipError(EIO, @"Could not validate the session manifest.");
            success = NO;
            break;
        }
        if (!readCount) break;
        [pending appendBytes:buffer length:(NSUInteger)readCount];
        const uint8_t *bytes = pending.bytes;
        NSUInteger consumed = 0;
        for (NSUInteger index = 0; index < pending.length; index++) {
            if (bytes[index] != '\n') continue;
            @autoreleasepool {
                NSUInteger length = index - consumed;
                if (length > 262145) {
                    success = SDKTZipFail(error, EFBIG, @"A manifest record exceeds the supported size.");
                    break;
                }
                NSString *line = [[NSString alloc] initWithBytes:bytes + consumed length:length encoding:NSUTF8StringEncoding];
                consumed = index + 1;
                if (!line) { success = SDKTZipFail(error, EINVAL, @"The session manifest is not valid UTF-8."); break; }
                lineNumber++;
                if (lineNumber == 1) {
                    NSString *suffix = @",\"events\":[";
                    if (![line hasSuffix:suffix]) {
                        success = SDKTZipFail(error, EINVAL, @"The manifest is not a finalized SDKtools session.");
                        break;
                    }
                    NSString *header = [[line substringToIndex:line.length - suffix.length] stringByAppendingString:@"}"];
                    NSDictionary *metadata = [NSJSONSerialization JSONObjectWithData:[header dataUsingEncoding:NSUTF8StringEncoding]
                                                                              options:0 error:error];
                    if (![metadata isKindOfClass:NSDictionary.class] ||
                        ![metadata[@"schema"] isEqual:@"sdktools.session.v1"] ||
                        ![metadata[@"event_count"] isKindOfClass:NSNumber.class]) {
                        success = SDKTZipFail(error, EINVAL, @"The manifest metadata is invalid.");
                        break;
                    }
                    declaredEvents = [metadata[@"event_count"] unsignedIntegerValue];
                    if (declaredEvents > 60000) {
                        success = SDKTZipFail(error, EFBIG, @"The manifest exceeds the event limit.");
                        break;
                    }
                } else if ([line isEqualToString:@"]}"]) {
                    if (closed) { success = SDKTZipFail(error, EINVAL, @"The manifest contains duplicate endings."); break; }
                    closed = YES;
                } else if (line.length > 0) {
                    if (closed) { success = SDKTZipFail(error, EINVAL, @"The manifest has trailing content."); break; }
                    if ([line hasSuffix:@","]) line = [line substringToIndex:line.length - 1];
                    NSDictionary *event = [NSJSONSerialization JSONObjectWithData:[line dataUsingEncoding:NSUTF8StringEncoding]
                                                                           options:0 error:error];
                    if (![event isKindOfClass:NSDictionary.class] || ++eventCount > 60000) {
                        success = SDKTZipFail(error, EINVAL, @"The manifest contains an invalid event.");
                        break;
                    }
                    if ([event[@"type"] isEqual:@"screenshot"]) {
                        NSDictionary *data = event[@"data"];
                        if (![data isKindOfClass:NSDictionary.class]) {
                            success = SDKTZipFail(error, EINVAL, @"A screenshot event is invalid."); break;
                        }
                        NSString *name = data[@"file"];
                        if ([data[@"status"] isEqual:@"captured"] || name) {
                            BOOL safeName = [name isKindOfClass:NSString.class] &&
                                [name hasPrefix:@"frames/"] && name.pathComponents.count == 2 &&
                                [name.pathExtension.lowercaseString isEqualToString:@"jpg"];
                            if (!safeName || ![names containsObject:name]) {
                                success = SDKTZipFail(error, ENOENT, @"A screenshot referenced by session.json is missing.");
                                break;
                            }
                        }
                    }
                }
            }
        }
        if (!success) break;
        if (consumed) [pending replaceBytesInRange:NSMakeRange(0, consumed) withBytes:NULL length:0];
        if (pending.length > 262145) success = SDKTZipFail(error, EFBIG, @"A manifest record exceeds the supported size.");
    }
    [stream close];
    if (success && (!closed || pending.length || eventCount != declaredEvents)) {
        success = SDKTZipFail(error, EINVAL, @"The session manifest is incomplete.");
    }
    return success;
}

@implementation SDKTZipWriter

+ (BOOL)archiveDirectory:(NSURL *)directory toURL:(NSURL *)destination error:(NSError **)error {
    if (!directory.isFileURL || !destination.isFileURL) {
        return SDKTZipFail(error, EINVAL, @"Archive paths must be local file URLs.");
    }
    NSFileManager *manager = NSFileManager.defaultManager;
    NSURL *manifestURL = [directory URLByAppendingPathComponent:@"session.json"];
    NSNumber *regular = nil;
    NSNumber *symlink = nil;
    if (![manifestURL getResourceValue:&regular forKey:NSURLIsRegularFileKey error:error] ||
        ![manifestURL getResourceValue:&symlink forKey:NSURLIsSymbolicLinkKey error:error]) return NO;
    if (!regular.boolValue || symlink.boolValue) {
        return SDKTZipFail(error, EINVAL, @"The finalized session.json is missing or invalid.");
    }

    NSMutableArray<NSString *> *names = [NSMutableArray arrayWithObject:@"session.json"];
    NSURL *framesURL = [directory URLByAppendingPathComponent:@"frames" isDirectory:YES];
    BOOL framesDirectory = NO;
    if ([manager fileExistsAtPath:framesURL.path isDirectory:&framesDirectory]) {
        if (!framesDirectory) return SDKTZipFail(error, EINVAL, @"The frames path is not a directory.");
        NSNumber *framesLink = nil;
        if (![framesURL getResourceValue:&framesLink forKey:NSURLIsSymbolicLinkKey error:error]) return NO;
        if (framesLink.boolValue) return SDKTZipFail(error, EINVAL, @"Symbolic links are not archived.");
        NSArray<NSURL *> *frameURLs = [manager contentsOfDirectoryAtURL:framesURL
                                           includingPropertiesForKeys:@[NSURLIsRegularFileKey,
                                                                         NSURLIsSymbolicLinkKey]
                                                              options:0 error:error];
        if (!frameURLs) return NO;
        for (NSURL *url in frameURLs) {
            if (![url.pathExtension.lowercaseString isEqualToString:@"jpg"]) continue;
            NSNumber *isFile = nil;
            NSNumber *isLink = nil;
            if (![url getResourceValue:&isFile forKey:NSURLIsRegularFileKey error:error] ||
                ![url getResourceValue:&isLink forKey:NSURLIsSymbolicLinkKey error:error]) return NO;
            if (!isFile.boolValue || isLink.boolValue) {
                return SDKTZipFail(error, EINVAL, @"A frame is missing, irregular, or a symbolic link.");
            }
            [names addObject:[@"frames/" stringByAppendingString:url.lastPathComponent]];
        }
    }
    [names sortUsingSelector:@selector(compare:)];
    if (names.count > UINT16_MAX) {
        return SDKTZipFail(error, EFBIG, @"Too many files for this ZIP format.");
    }
    if (!SDKTVerifyFrameReferences(manifestURL, [NSSet setWithArray:names], error)) return NO;
    if ([manager fileExistsAtPath:destination.path]) {
        return SDKTZipFail(error, EEXIST, @"An archive already exists at the export destination.");
    }
    NSURL *partialURL = [destination.URLByDeletingLastPathComponent
        URLByAppendingPathComponent:[NSString stringWithFormat:@".%@.%@.partial",
                                     destination.lastPathComponent, NSUUID.UUID.UUIDString]];
    int output = open(partialURL.fileSystemRepresentation, O_CREAT | O_EXCL | O_WRONLY | O_CLOEXEC, 0600);
    if (output < 0) return SDKTZipFail(error, errno, @"Could not create the temporary ZIP file.");

    BOOL success = YES;
    uint64_t position = 0;
    uint64_t totalInput = 0;
    NSMutableData *central = [NSMutableData data];
    NSDateComponents *components = [[NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian]
        components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay |
                   NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond
          fromDate:NSDate.date];
    NSUInteger year = MIN(MAX(components.year, 1980), 2107);
    uint16_t dosDate = (uint16_t)(((year - 1980) << 9) | (components.month << 5) | components.day);
    uint16_t dosTime = (uint16_t)((components.hour << 11) | (components.minute << 5) | (components.second / 2));

    for (NSString *name in names) {
        @autoreleasepool {
            NSURL *sourceURL = [directory URLByAppendingPathComponent:name];
            int input = open(sourceURL.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
            if (input < 0) {
                success = SDKTZipFail(error, errno, @"A session file could not be opened for export.");
                break;
            }
            struct stat status;
            if (fstat(input, &status) != 0 || !S_ISREG(status.st_mode) || status.st_size < 0) {
                close(input);
                success = SDKTZipFail(error, EINVAL, @"Only regular session files can be exported.");
                break;
            }
            uint64_t size = (uint64_t)status.st_size;
            NSData *nameData = [name dataUsingEncoding:NSUTF8StringEncoding];
            if (size > UINT32_MAX || position > UINT32_MAX || !nameData ||
                nameData.length > UINT16_MAX || totalInput + size > SDKTZipMaximumInputBytes) {
                close(input);
                success = SDKTZipFail(error, EFBIG, @"The capture exceeds the 250 MiB export limit.");
                break;
            }
            uint32_t checksum = 0;
            if (!SDKTReadCRC(input, size, &checksum, error)) {
                close(input);
                success = NO;
                break;
            }
            NSMutableData *local = [NSMutableData data];
            SDKTLE32(local, 0x04034b50); SDKTLE16(local, 20); SDKTLE16(local, 0x0800);
            SDKTLE16(local, 0); SDKTLE16(local, dosTime); SDKTLE16(local, dosDate);
            SDKTLE32(local, checksum); SDKTLE32(local, (uint32_t)size); SDKTLE32(local, (uint32_t)size);
            SDKTLE16(local, (uint16_t)nameData.length); SDKTLE16(local, 0);
            [local appendData:nameData];
            success = SDKTWriteData(output, local, error);
            uint64_t copied = 0;
            uLong copyCRC = crc32(0L, Z_NULL, 0);
            uint8_t buffer[65536];
            while (success) {
                ssize_t length = read(input, buffer, sizeof(buffer));
                if (length < 0 && errno == EINTR) continue;
                if (length < 0) { success = SDKTZipFail(error, errno, @"Could not copy an export file."); break; }
                if (length == 0) break;
                copied += (uint64_t)length;
                if (copied > size) { success = SDKTZipFail(error, EIO, @"An export file changed while copying."); break; }
                copyCRC = crc32(copyCRC, buffer, (uInt)length);
                success = SDKTWriteBytes(output, buffer, (size_t)length, error);
            }
            close(input);
            if (success && (copied != size || (uint32_t)copyCRC != checksum)) {
                success = SDKTZipFail(error, EIO, @"An export file changed while copying.");
            }
            if (!success) break;
            SDKTLE32(central, 0x02014b50); SDKTLE16(central, (3 << 8) | 20); SDKTLE16(central, 20);
            SDKTLE16(central, 0x0800); SDKTLE16(central, 0); SDKTLE16(central, dosTime); SDKTLE16(central, dosDate);
            SDKTLE32(central, checksum); SDKTLE32(central, (uint32_t)size); SDKTLE32(central, (uint32_t)size);
            SDKTLE16(central, (uint16_t)nameData.length); SDKTLE16(central, 0); SDKTLE16(central, 0);
            SDKTLE16(central, 0); SDKTLE16(central, 0); SDKTLE32(central, (uint32_t)(S_IFREG | 0600) << 16);
            SDKTLE32(central, (uint32_t)position); [central appendData:nameData];
            position += local.length + size;
            totalInput += size;
        }
    }
    if (success && (position > UINT32_MAX || central.length > UINT32_MAX)) {
        success = SDKTZipFail(error, EFBIG, @"The archive requires unsupported ZIP64 offsets.");
    }
    if (success) success = SDKTWriteData(output, central, error);
    if (success) {
        NSMutableData *end = [NSMutableData data];
        SDKTLE32(end, 0x06054b50); SDKTLE16(end, 0); SDKTLE16(end, 0);
        SDKTLE16(end, (uint16_t)names.count); SDKTLE16(end, (uint16_t)names.count);
        SDKTLE32(end, (uint32_t)central.length); SDKTLE32(end, (uint32_t)position); SDKTLE16(end, 0);
        success = SDKTWriteData(output, end, error);
    }
    if (success && fsync(output) != 0) success = SDKTZipFail(error, errno, @"Could not synchronize the exported ZIP.");
    if (close(output) != 0 && success) success = SDKTZipFail(error, errno, @"Could not close the exported ZIP.");
    if (success) success = [manager moveItemAtURL:partialURL toURL:destination error:error];
    if (!success) [manager removeItemAtURL:partialURL error:nil];
    return success;
}
@end
