# SDKtools 0.1 — captura local do WePlay

Primeira implementação do menu flutuante para investigar a entrada no Crazy Alpaca e uma partida. **Este pacote contém fontes e workflow. A compilação iOS e o teste em aparelho ainda precisam acontecer.**

## O que foi implementado

- Botão circular **SDK**, 44 pt, escuro com detalhe verde, discreto no canto. Arraste para reposicionar; toque para abrir **SDKtools**.
- **Iniciar captura**: sequência de imagens, telas nativas, toques e metadados disponíveis do conteúdo web/Cocos.
- **Marcar: entrei no Crazy Alpaca**: marcação sua na linha do tempo; não é uma confirmação automática do nome interno Sheep.
- **Parar e exportar ZIP**: `session.json` e pasta `frames/`, com compartilhamento pelo iOS.
- **Compartilhar última captura**: recupera a última exportação finalizada.

A primeira versão produz **imagens em sequência, não um vídeo MP4**. A cadência periódica é 1 imagem/s, com imagens adicionais após toques, respeitando intervalo mínimo de 0,5 s e uma captura pendente. Movimentos são amostrados em até 20 Hz por toque. Limite por sessão: 5 minutos, 60 mil eventos e 250 MiB de dados; o ZIP de exportação ocupa espaço adicional.

O código não implementa raio-x ou autoplay. A captura é a etapa para descobrir como o tabuleiro aparece e quais dados podem ser associados aos cards. Não existe ainda um mapeamento validado de card, identidade, par ou jogada.

## Compilar e gerar o IPA pelo GitHub Actions

O kit de entrega contém **SDKtools-projeto.zip**, **.github/workflows/compilar.yml** e um guia curto. Você pode subir o ZIP de fontes fechado: o workflow faz a extração no runner. O arquivo do workflow precisa existir fora do ZIP, no caminho indicado.

1. Crie seu repositório e envie **SDKtools-projeto.zip na raiz**, sem renomear.
2. Crie o arquivo **.github/workflows/compilar.yml** na branch principal e cole o conteúdo do arquivo de mesmo nome entregue no kit.
3. Extraia o `.ipa` do RAR original. Em **Releases**, crie uma release publicada com a tag **weplay-base** e anexe **com.wejoy.weplay_6.12.0_und3fined.ipa**. Prefira repositório privado para restringir o IPA à sua conta/equipe.
4. Abra **Actions → Compilar SDKtools IPA → Run workflow**. Os campos já usam a tag e o nome acima; se você mudou esses nomes, ajuste-os no formulário.
5. Após o job terminar com sucesso, abra **Artifacts → WePlay-SDKtools-unsigned**. Extraia o download: o arquivo final será **WePlay-SDKtools-unsigned.ipa**, acompanhado do relatório de preparação.
6. Assine esse IPA no GBox, incluindo seu código interno, e teste a instalação e a abertura. A compatibilidade no aparelho ainda não foi verificada.

**O IPA base é necessário.** As fontes do SDKtools não incluem o código-fonte nem os recursos completos do WePlay. O workflow compila a biblioteca, baixa o IPA da sua release, integra a biblioteca e o bundle e verifica o pacote final. Sem IPA base, o job falha com uma mensagem; não apresenta uma compilação só de dylib como entrega concluída.

O IPA tem cerca de 514 MB, acima do limite de envio normal de arquivos pelo navegador ao repositório. Por isso ele vai nos anexos de uma Release. Não envie o RAR nesse campo nem coloque o IPA no histórico Git.

O job usa runner `macos-15`, Xcode e SDK oficial. Seu token temporário tem apenas `contents: read`, e a origem do IPA está limitada ao mesmo repositório. Não é necessário enviar `.p12`, senha ou perfil de provisionamento para compilar. A assinatura ad hoc da biblioteca não substitui a assinatura final do IPA.

Também é possível subir os fontes descompactados na raiz: o workflow detecta esse formato. No modo ZIP, ele não modifica seu repositório: extrai em uma pasta temporária do runner.

### Integração local opcional

Após compilar em macOS/Xcode com `bash scripts/build.sh`, o equivalente à integração do workflow é:

```bash
python3 tools/prepare_ipa.py \
  --ipa /caminho/com.wejoy.weplay_6.12.0_und3fined.ipa \
  --dylib build/SDKtools.dylib \
  --resources build/SDKtools.bundle \
  --output /caminho/WePlay-SDKtools-unsigned.ipa
```

O empacotador preserva o original, aceita somente padding Mach-O comprovadamente livre, rejeita `cryptid != 0` e verifica os arquivos por SHA-256 e CRC. Não descriptografa, não desloca seções e não assina. As assinaturas do pacote precisam ser refeitas antes da instalação normal.

Referências: [limites de arquivos do GitHub](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository), [assets de Releases](https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases) e [execução manual de workflows](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow).

## Como fazer a primeira captura

1. Abra o WePlay modificado. O botão SDK deverá aparecer após a janela principal ficar ativa.
2. Antes de entrar no jogo, toque **SDK → Iniciar captura**. O ponto vermelho indica captura ativa.
3. Navegue até o Crazy Alpaca. Abra SDKtools e toque **Marcar: entrei no Crazy Alpaca**.
4. Entre em uma partida e realize algumas jogadas, incluindo combinações e mudanças de tela que queira analisar.
5. Toque **SDK → Parar e exportar ZIP**. Salve ou compartilhe o arquivo.
6. Envie esse ZIP na conversa. Ele permite correlacionar as imagens, posições dos toques, telas e elementos disponíveis. Uma marcação sua é separada das evidências coletadas.

A captura para ao sair do estado ativo do aplicativo. Não reinicia sozinha. Imagens podem conter nomes, conversas ou outros dados visíveis: revise antes de compartilhar. Não há upload automático, áudio, câmera, captura de outros aplicativos, cookies ou leitura de valores de formulários.

## O que o JSON consegue dizer

- `screen`: classes dos controladores e views nativas, retângulos em pontos da janela, mudanças de caminho e limites da inspeção. Sem texto dos controles.
- `touch`: fase, identificador temporário, coordenadas em pontos e normalizadas, classe da view tocada. Não lê o que foi digitado.
- `web_snapshot`: retângulos DOM/canvas e, quando `window.cc` estiver acessível, metadados públicos de nós Cocos ativos. Posições Cocos são locais, não coordenadas de tela comprovadas.
- `screenshot`: caminho relativo do JPEG, horário, dimensões, renderer e sucesso/falha.
- `mark`, `lifecycle`, `error`: marcações, interrupções e lacunas.

Há dois horários para snapshots web: solicitação e conclusão. Isso evita tratar uma resposta atrasada como simultânea ao toque. A identidade visual de Sheep/Crazy Alpaca exige examinar imagens e caminho; nomes de classes não bastam.

**Limites visuais:** `drawViewHierarchyInRect` pode não incluir WebGL, vídeo ou conteúdo protegido. Um JPEG gravado não garante que o tabuleiro esteja visível. Se os cards saírem pretos ou ausentes, envie também uma gravação de tela feita pelo iOS para correlacionar com o JSON. Nós ativos podem estar cobertos por outros; o probe registra essa incerteza. Cocos não exposto em `window.cc`, iframes e APIs incompletas reduzem a cobertura. Nenhum estado oculto foi reconstruído.

O probe lê no máximo 200 elementos DOM e 400 nós Cocos, com orçamento cooperativo de 100 ms; uma chamada JavaScript bloqueada não pode ser cancelada por esse orçamento. O host abandona respostas após 5 s e tenta novamente apenas em outra sessão. A captura evita interferir no reconhecimento de gestos, mas essa propriedade ainda precisa ser testada no aparelho.

## Analisar o ZIP no computador

```bash
python3 tools/analyze_session.py /caminho/captura.zip
```

O analisador também aceita `session.json`. Ele não precisa extrair o ZIP. Verifica referências de imagens e tempos, resume eventos e aponta lacunas sem confirmar automaticamente Sheep ou todos os cards. Veja `docs/JSON_FORMAT.md`.

## Estado da validação

- Testes locais do probe JavaScript com DOM/Cocos simulados e do empacotador/analisador Python.
- Revisão estática dos módulos Objective-C, ciclo de vida e exportação ZIP.
- Inspeção do IPA fornecido: espaço de header suficiente para a dependência adicional.
- **Pendente:** compilação real no GitHub Actions, assinatura final, instalação, renderização do tabuleiro, toque e estabilidade em iPhone.

Um build verde prova compilação e as verificações executadas, não compatibilidade com uma partida. Primeiro teste sugerido: iniciar uma captura curta, abrir o jogo, parar, confirmar que o ZIP contém imagens úteis e JSON válido; só depois capturar uma partida completa.

## Estrutura

| Caminho | Função |
|---|---|
| `Sources/SDKTools.m` | Botão/menu, observação passiva de toques, navegação e WebKit |
| `Sources/SDKTCaptureSession.*` | Sessão, journal, imagens e JSON final |
| `Sources/SDKTZipWriter.*` | Exportação ZIP local |
| `Resources/sdktools_probe.js` | Inspeção limitada do conteúdo web/Cocos |
| `scripts/build.sh` | Compilação e inspeção com Xcode |
| `.github/workflows/compilar.yml` | Build e integração obrigatória com IPA de uma release |
| `tools/prepare_ipa.py` | Integração em cópia do IPA |
| `tools/analyze_session.py` | Resumo e consistência das capturas |

O carregamento do menu está limitado ao executável `weplay`. Outro nome de executável exige ajuste explícito no projeto. O SDK da Apple e o IPA original não são incluídos neste pacote de fontes.
