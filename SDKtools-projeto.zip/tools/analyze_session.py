#!/usr/bin/env python3
"""Summarize an SDKtools capture without inferring hidden game state.

Accepts session.json or a ZIP export with session.json and frames/. No networking,
screen OCR, game automation, or modification of the captured app is performed.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime
import json
import math
from pathlib import Path
import re
import sys
import zipfile

from prepare_ipa import Limits, PreparationError, safe_zip_name, validate_zip

SCHEMA = "sdktools.session.v1"
KNOWN_EVENTS = {"touch", "screenshot", "screen", "web_snapshot", "mark", "error", "lifecycle", "session_start", "session_stop"}
MAX_JSON_BYTES = 64 * 1024**2
MAX_EVENTS = 200_000


def number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def class_names(value) -> set[str]:
    """Collect class identifiers only; never echo general captured text fields."""
    result = set()
    pending = [value]
    seen = 0
    while pending and seen < 100_000:
        node = pending.pop()
        seen += 1
        if isinstance(node, dict):
            for key, item in node.items():
                if key in {"class", "class_name", "controller_class", "view_class", "target_class"}:
                    if isinstance(item, str) and re.fullmatch(r"[A-Za-z_][A-Za-z_0-9.]{0,255}", item):
                        result.add(item)
                elif key == "controllers" and isinstance(item, list):
                    result.update(name for name in item if isinstance(name, str) and re.fullmatch(r"[A-Za-z_][A-Za-z_0-9.]{0,255}", name))
                if isinstance(item, (dict, list)):
                    pending.append(item)
        elif isinstance(node, list):
            pending.extend(node)
    return result


def analyze(session: dict, *, files: set[str] | None = None) -> dict:
    if not isinstance(session, dict):
        raise ValueError("Session JSON root must be an object")
    version = session.get("schema", session.get("schema_version"))
    if version != SCHEMA:
        raise ValueError(f"Expected schema {SCHEMA!r}, found {version!r}")
    events = session.get("events")
    if not isinstance(events, list) or len(events) > MAX_EVENTS:
        raise ValueError("events must be an array with at most 200000 entries")
    warnings: list[dict] = []
    warning_counts: Counter = Counter()

    def warn(code: str, message: str, index: int | None = None):
        warning_counts[code] += 1
        if len(warnings) < 100:
            item = {"code": code, "message": message}
            if index is not None:
                item["event_index"] = index
            warnings.append(item)

    for field in ("session_id", "started_at", "duration_ms", "app", "capture_config"):
        if field not in session:
            warn("missing_field", f"Missing top-level field: {field}")
    started = session.get("started_at")
    if isinstance(started, str):
        try:
            parsed = datetime.fromisoformat(started.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                warn("timestamp_without_timezone", "started_at has no time zone")
        except ValueError:
            warn("invalid_started_at", "started_at is not a valid ISO-8601 timestamp")
    else:
        warn("invalid_started_at", "started_at must be a string")
    duration = session.get("duration_ms")
    if not number(duration) or duration < 0:
        warn("invalid_duration", "duration_ms must be a finite nonnegative number")
        duration = None
    elif duration > 300_000 + 1000:
        warn("duration_above_capture_limit", "Capture exceeds the expected 300-second recorder limit")
    declared_count = session.get("event_count")
    if declared_count is not None and declared_count != len(events):
        warn("event_count_mismatch", "event_count differs from the number of exported events")
    capture_stats = session.get("capture_stats")
    safe_capture_stats = {}
    if isinstance(capture_stats, dict):
        for key in ("requested", "dropped", "written", "failed"):
            value = capture_stats.get(key)
            if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
                safe_capture_stats[key] = value
        if safe_capture_stats.get("dropped", 0):
            warn("captures_dropped", "Recorder omitted screenshot requests; inspect capture_stats")
        if safe_capture_stats.get("failed", 0):
            warn("captures_failed", "Recorder reports unsuccessful screenshots; inspect capture_stats")
    if isinstance(session.get("warnings"), list) and session["warnings"]:
        warn("recorder_warnings", "Recorder emitted warnings; review the original session.json")

    counts: Counter = Counter()
    screenshot_status: Counter = Counter()
    touch_phases: Counter = Counter()
    observed_classes: set[str] = set()
    screenshots = []
    references: set[str] = set()
    active_touches: set[str] = set()
    completed_touches = 0
    marks = 0
    readable_web_snapshots = 0
    cocos_status_counts: Counter = Counter()
    entry_mark_seen = False
    previous_t = None
    first_t = None
    last_t = None
    for index, event in enumerate(events):
        if not isinstance(event, dict):
            warn("invalid_event", "Event is not an object", index)
            continue
        kind = event.get("type")
        if not isinstance(kind, str):
            warn("invalid_event_type", "Event type must be a string", index)
            continue
        counts[kind] += 1
        if kind not in KNOWN_EVENTS:
            warn("unknown_event_type", f"Unrecognized event type: {kind[:80]}", index)
        t = event.get("t_ms")
        if not number(t) or t < 0:
            warn("invalid_event_time", "t_ms must be a finite nonnegative number", index)
        else:
            if previous_t is not None and t < previous_t:
                warn("nonmonotonic_time", "Event timestamp precedes the preceding event", index)
            if duration is not None and t > duration + 1:
                warn("event_after_session_end", "Event timestamp exceeds duration_ms", index)
            previous_t = t
            first_t = t if first_t is None else min(first_t, t)
            last_t = t if last_t is None else max(last_t, t)
        data = event.get("data")
        if not isinstance(data, dict):
            warn("invalid_event_data", "Event data must be an object", index)
            continue
        observed_classes |= class_names(data)
        if kind == "touch":
            phase = data.get("phase")
            if not isinstance(phase, str):
                warn("invalid_touch_phase", "Touch phase must be a string", index)
                continue
            touch_phases[phase] += 1
            identifier = data.get("touch_id")
            if not isinstance(identifier, (str, int)) or isinstance(identifier, bool):
                warn("missing_touch_id", "Touch has no usable touch_id", index)
                continue
            key = str(identifier)
            if phase in {"began", "begin", "down"}:
                if key in active_touches:
                    warn("duplicate_touch_begin", "Touch begins before the same ID ends", index)
                active_touches.add(key)
            elif phase in {"moved", "move", "stationary"}:
                if key not in active_touches:
                    warn("touch_without_begin", "Touch update has no preceding begin in this capture", index)
            elif phase in {"ended", "end", "up", "cancelled", "canceled", "cancel"}:
                if key not in active_touches:
                    warn("touch_without_begin", "Touch end has no preceding begin in this capture", index)
                else:
                    completed_touches += 1
                active_touches.discard(key)
            else:
                warn("unknown_touch_phase", "Unrecognized touch phase", index)
            # Current recorder uses x/y window points and normalized_x/y ratios.
            normalized = ("normalized_x", "normalized_y") if data.get("coordinate_space") == "window_points" else ("x", "y")
            if data.get("coordinate_space") == "window_points":
                for coordinate in ("x", "y"):
                    if not number(data.get(coordinate)):
                        warn("invalid_touch_point", f"Touch {coordinate} must be a finite number of window points", index)
            for coordinate in normalized:
                value = data.get(coordinate)
                if not number(value) or not 0 <= value <= 1:
                    warn("touch_outside_window_or_invalid", f"Touch {coordinate} is missing, invalid, or outside [0, 1]; a gesture can leave the window", index)
        elif kind == "screenshot":
            status = data.get("status", "unspecified")
            screenshot_status[str(status)[:80]] += 1
            name = data.get("file")
            if name is not None:
                try:
                    safe_zip_name(name)
                    if not name.startswith("frames/"):
                        raise PreparationError("Frame path must be within frames/")
                    if name in references:
                        warn("duplicate_frame_reference", "Multiple screenshot events reference the same file", index)
                    references.add(name)
                    if files is not None and name not in files:
                        warn("missing_frame_file", "Referenced screenshot is missing from the export", index)
                    screenshots.append({"t_ms": t, "file": name, "status": status,
                                        "width_px": data.get("width_px"), "height_px": data.get("height_px")})
                except (PreparationError, TypeError):
                    warn("unsafe_frame_path", "Screenshot file path is invalid or outside frames/", index)
            elif status in {"ok", "success", "captured"}:
                warn("missing_frame_reference", "Successful screenshot has no file reference", index)
            if name is not None:
                for dimension in ("width_px", "height_px"):
                    if not number(data.get(dimension)) or data[dimension] <= 0:
                        warn("invalid_frame_dimensions", f"Screenshot {dimension} must be positive", index)
        elif kind == "web_snapshot":
            # A successful DOM snapshot still does not reveal canvas/WebGL game state.
            snapshot = data.get("snapshot")
            if isinstance(snapshot, dict) and snapshot.get("schema") == "sdktools.web.v1":
                readable_web_snapshots += 1
                engine = snapshot.get("engine")
                cocos = engine.get("cocos") if isinstance(engine, dict) else None
                if isinstance(cocos, dict) and isinstance(cocos.get("status"), str):
                    cocos_status_counts[cocos["status"]] += 1
            elif data.get("status") in {"ok", "success", "captured"}:
                readable_web_snapshots += 1
            else:
                warn("unknown_web_snapshot_schema", "Web snapshot does not use sdktools.web.v1", index)
        elif kind == "mark":
            marks += 1
            if data.get("label") == "entered_crazy_alpaca":
                entry_mark_seen = True
    if active_touches:
        warn("unfinished_touches", f"{len(active_touches)} touch sequence(s) remain open; capture may end mid-gesture")
    missing = []
    if not counts["touch"]:
        missing.append("touch_events")
    if not screenshots:
        missing.append("screenshot_references")
    if not counts["screen"]:
        missing.append("native_screen_snapshots")
    if not entry_mark_seen:
        missing.append("user_mark_entered_crazy_alpaca")
    if not counts["web_snapshot"]:
        missing.append("web_snapshot_events")
    if files is None:
        missing.append("frame_file_availability_unverified")
    elif references:
        extra = sum(name.startswith("frames/") and not name.endswith("/") and name not in references for name in files)
        if extra:
            warn("unreferenced_frames", f"{extra} frame file(s) are not referenced by screenshot events")
    sheep_indicators = sorted(name for name in observed_classes if "sheep" in name.lower())
    app = session.get("app") if isinstance(session.get("app"), dict) else {}
    safe_app = {key: app[key] for key in ("bundle_id", "bundle_identifier", "version", "build") if isinstance(app.get(key), (str, int))}
    return {
        "analysis_schema": "sdktools.analysis.v1",
        "session_id": session.get("session_id"), "app": safe_app,
        "duration_ms": duration, "observed_time_range_ms": [first_t, last_t],
        "event_counts": dict(sorted(counts.items())),
        "touch_summary": {"phase_counts": dict(sorted(touch_phases.items())), "completed_sequences": completed_touches,
                          "unfinished_sequences": len(active_touches)},
        "screenshot_summary": {"status_counts": dict(sorted(screenshot_status.items())),
                               "distinct_file_references": len(references), "files_checked": files is not None,
                               "capture_stats": safe_capture_stats},
        "web_snapshot_summary": {"success_status_count": readable_web_snapshots,
                                 "cocos_status_counts": dict(sorted(cocos_status_counts.items())),
                                 "canvas_or_webgl_contents_interpreted": False},
        "sheep_correspondence": {"status": "requires_manual_visual_confirmation", "class_name_indicators": sheep_indicators,
                                 "user_entry_mark_present": entry_mark_seen,
                                 "explanation": "Class names and marks alone do not establish that the visible match is Crazy Alpaca. Compare route screenshots and match frames with the observed screen classes."},
        "coverage_gaps": missing, "warning_counts": dict(sorted(warning_counts.items())), "warnings": warnings,
        "warning_details_truncated": sum(warning_counts.values()) > len(warnings),
        "limitations": ["No OCR or visual card recognition was performed.",
                        "Only captured visible content and metadata can be assessed; hidden cards and server state are not inferred.",
                        "No replay, automatic moves, or game-control actions were performed."],
    }


def load_session(path: Path) -> tuple[dict, set[str] | None]:
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            infos = validate_zip(archive, Limits(total_bytes=1024**3, entry_bytes=128 * 1024**2, entries=10_000))
            names = {info.filename for info in infos}
            if "session.json" not in names:
                raise ValueError("ZIP export must have session.json at its root")
            if archive.getinfo("session.json").file_size > MAX_JSON_BYTES:
                raise ValueError("Session JSON exceeds 64 MiB")
            with archive.open("session.json") as stream:
                raw = stream.read(MAX_JSON_BYTES + 1)
            # Read all members once to verify CRC without extracting paths.
            bad = archive.testzip()
            if bad is not None:
                raise ValueError(f"Export ZIP failed CRC validation: {bad}")
        return json.loads(raw), names
    if path.stat().st_size > MAX_JSON_BYTES:
        raise ValueError("Session JSON exceeds 64 MiB")
    with path.open("r", encoding="utf-8") as stream:
        session = json.load(stream)
    # Standalone JSON can accompany a frames directory. Do not follow symlinks.
    frames = path.parent / "frames"
    available = None
    if frames.is_dir() and not frames.is_symlink():
        available = {"session.json"}
        for file in frames.rglob("*"):
            if file.is_file() and not any(p.is_symlink() for p in [file, *file.parents] if p != path.parent):
                available.add(file.relative_to(path.parent).as_posix())
    return session, available


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("session", type=Path, help="session.json or exported ZIP")
    parser.add_argument("--output", type=Path, help="Optional new JSON summary file; never overwritten")
    args = parser.parse_args()
    try:
        session, files = load_session(args.session)
        result = analyze(session, files=files)
        text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            with args.output.open("x", encoding="utf-8") as handle:
                handle.write(text)
        else:
            print(text, end="")
    except (ValueError, OSError, zipfile.BadZipFile, RuntimeError, RecursionError) as exc:
        print(f"SDKtools session analysis failed: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
