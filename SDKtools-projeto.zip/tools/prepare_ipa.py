#!/usr/bin/env python3
"""Prepare an unsigned IPA with SDKtools. Never execute or sign supplied code.

Only thin, device arm64 Mach-O images are supported. The injector uses existing
zero header padding; it never moves sections, rewrites instruction pointers, or
attempts decryption. Python 3.9+; standard library only.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import plistlib
import re
import stat
import struct
import sys
import tempfile
import zipfile
from dataclasses import dataclass

MAGIC = 0xFEEDFACF
CPU_ARM64 = 0x0100000C
MH_EXECUTE, MH_DYLIB = 2, 6
LC_SEGMENT_64, LC_LOAD_DYLIB, LC_ID_DYLIB = 0x19, 0xC, 0xD
LOAD_DYLIB_COMMANDS = {0xC, 0x80000018, 0x8000001F, 0x20, 0x80000023}
INJECT_PATH = "@executable_path/Frameworks/SDKtools.dylib"
ALLOWED_INSTALL_NAMES = {"@rpath/SDKtools.dylib", INJECT_PATH}
CHUNK = 1024 * 1024
MAX_MACHO = 512 * 1024 * 1024


class PreparationError(ValueError):
    """An input cannot be prepared without making unsupported assumptions."""


@dataclass(frozen=True)
class Limits:
    total_bytes: int = 8 * 1024**3
    entry_bytes: int = 2 * 1024**3
    entries: int = 100_000


def version_tuple(value: str) -> tuple[int, int, int]:
    if not isinstance(value, str) or not re.fullmatch(r"\d+(?:\.\d+){0,2}", value):
        raise PreparationError(f"Invalid iOS version: {value!r}")
    parts = [int(v) for v in value.split(".")]
    return tuple((parts + [0, 0])[:3])


def version_string(value: tuple[int, int, int]) -> str:
    return ".".join(map(str, value))


def packed_version(value: int) -> tuple[int, int, int]:
    return value >> 16, (value >> 8) & 255, value & 255


def safe_zip_name(name: str, *, directory: bool = False) -> str:
    if not isinstance(name, str) or not name:
        raise PreparationError("Empty archive path")
    if any(ord(c) < 32 or ord(c) == 127 for c in name):
        raise PreparationError(f"Control character in archive path: {name!r}")
    if "\\" in name or ":" in name or name.startswith("/"):
        raise PreparationError(f"Unsafe archive path: {name!r}")
    candidate = name[:-1] if name.endswith("/") else name
    if not candidate or any(p in {"", ".", ".."} for p in candidate.split("/")):
        raise PreparationError(f"Unsafe archive path: {name!r}")
    if PurePosixPath(candidate).is_absolute() or (name.endswith("/") and not directory):
        raise PreparationError(f"Invalid archive path: {name!r}")
    return candidate


def validate_zip(archive: zipfile.ZipFile, limits: Limits) -> list[zipfile.ZipInfo]:
    infos = archive.infolist()
    if len(infos) > limits.entries:
        raise PreparationError("Archive has too many entries")
    paths: dict[str, bool] = {}
    total = 0
    for info in infos:
        if info.orig_filename != info.filename:
            raise PreparationError("Archive path was truncated while parsing")
        key = safe_zip_name(info.filename, directory=info.is_dir())
        if key in paths:
            raise PreparationError(f"Duplicate archive path: {key}")
        paths[key] = info.is_dir()
        mode_type = stat.S_IFMT(info.external_attr >> 16)
        if mode_type not in {0, stat.S_IFREG, stat.S_IFDIR}:
            raise PreparationError(f"Symlink or special file is unsupported: {key}")
        if mode_type == stat.S_IFDIR and not info.is_dir():
            raise PreparationError(f"Inconsistent directory entry: {key}")
        if info.flag_bits & 1:
            raise PreparationError(f"Encrypted ZIP entry is unsupported: {key}")
        if info.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}:
            raise PreparationError(f"Unsupported compression method: {key}")
        if info.file_size < 0 or info.file_size > limits.entry_bytes:
            raise PreparationError(f"Entry exceeds expanded size limit: {key}")
        total += info.file_size
        if total > limits.total_bytes:
            raise PreparationError("Archive exceeds total expanded size limit")
    for key in paths:
        parent = PurePosixPath(key).parent
        while str(parent) != ".":
            if str(parent) in paths and not paths[str(parent)]:
                raise PreparationError(f"File is used as a parent directory: {parent}")
            parent = parent.parent
    return infos


class MachO:
    def __init__(self, blob: bytes, *, expected_type: int):
        self.blob = blob
        if len(blob) < 32 or len(blob) > MAX_MACHO:
            raise PreparationError("Mach-O size is outside supported bounds")
        magic, cpu, subtype, kind, ncmds, sizeofcmds, _, _ = struct.unpack_from("<IiiIIIII", blob)
        if magic != MAGIC or cpu != CPU_ARM64 or (subtype & 0xFFFFFF) != 0:
            raise PreparationError("Only thin little-endian arm64 Mach-O is supported (no arm64e/fat images)")
        if kind != expected_type:
            raise PreparationError(f"Wrong Mach-O file type: expected {expected_type}, found {kind}")
        if ncmds == 0 or ncmds > 4096 or sizeofcmds > len(blob) - 32:
            raise PreparationError("Malformed Mach-O load-command region")
        self.ncmds, self.sizeofcmds = ncmds, sizeofcmds
        self.header_end = 32 + sizeofcmds
        self.commands = []
        self.dependencies: list[str] = []
        self.install_names: list[str] = []
        self.versions: list[tuple[int, int, int]] = []
        self.file_sections: list[tuple[int, int, str]] = []
        self.other_data_starts: list[int] = []
        self.text_ranges: list[tuple[int, int]] = []
        cursor = 32
        for _ in range(ncmds):
            if cursor + 8 > self.header_end:
                raise PreparationError("Truncated Mach-O load command")
            cmd, size = struct.unpack_from("<II", blob, cursor)
            if size < 8 or size % 8 or cursor + size > self.header_end:
                raise PreparationError("Invalid Mach-O command size/alignment")
            self.commands.append((cmd, cursor, size))
            self._parse_command(cmd, cursor, size)
            cursor += size
        if cursor != self.header_end:
            raise PreparationError("Mach-O command count and size do not match")
        if not self.file_sections:
            raise PreparationError("No file-backed sections available to verify header padding")
        if min(x[0] for x in self.file_sections) < self.header_end:
            raise PreparationError("A file-backed section overlaps Mach-O headers")
        if not self.versions or len(set(self.versions)) != 1:
            raise PreparationError("Missing or inconsistent iOS deployment target")
        self.minimum_ios = self.versions[0]

    def _range(self, offset: int, size: int, label: str) -> None:
        if size and (offset < 0 or offset > len(self.blob) or size > len(self.blob) - offset):
            raise PreparationError(f"Out-of-bounds Mach-O {label}")
        if size:
            if offset < self.header_end:
                raise PreparationError(f"Mach-O {label} overlaps header region")
            self.other_data_starts.append(offset)

    def _parse_command(self, cmd: int, at: int, size: int) -> None:
        b = self.blob
        if cmd in {0x21, 0x2C}:
            if size < (24 if cmd == 0x2C else 20):
                raise PreparationError("Truncated encryption command")
            cryptoff, cryptsize, cryptid = struct.unpack_from("<III", b, at + 8)
            if cryptid:
                raise PreparationError("Encrypted executable (cryptid != 0); no decryption is performed")
            # A zero cryptid makes this range inactive; do not treat it as extra padding.
            if cryptsize and cryptoff + cryptsize > len(b):
                raise PreparationError("Out-of-bounds encryption range")
        elif cmd in LOAD_DYLIB_COMMANDS | {LC_ID_DYLIB}:
            if size < 24:
                raise PreparationError("Truncated dylib command")
            name_offset = struct.unpack_from("<I", b, at + 8)[0]
            if not 24 <= name_offset < size:
                raise PreparationError("Invalid dylib name offset")
            end = b.find(b"\0", at + name_offset, at + size)
            if end < 0:
                raise PreparationError("Unterminated dylib name")
            try:
                name = b[at + name_offset:end].decode("utf-8")
            except UnicodeDecodeError as exc:
                raise PreparationError("Invalid UTF-8 dylib name") from exc
            (self.install_names if cmd == LC_ID_DYLIB else self.dependencies).append(name)
        elif cmd == 0x32:  # LC_BUILD_VERSION
            if size < 24:
                raise PreparationError("Truncated build-version command")
            platform, minimum, _, ntools = struct.unpack_from("<IIII", b, at + 8)
            if platform != 2:
                raise PreparationError("Mach-O platform is not device iOS")
            if 24 + ntools * 8 != size:
                raise PreparationError("Malformed build-version tool list")
            self.versions.append(packed_version(minimum))
        elif cmd == 0x25:  # LC_VERSION_MIN_IPHONEOS
            if size != 16:
                raise PreparationError("Malformed minimum-iOS command")
            self.versions.append(packed_version(struct.unpack_from("<I", b, at + 8)[0]))
        elif cmd == LC_SEGMENT_64:
            if size < 72:
                raise PreparationError("Truncated segment command")
            segname = b[at + 8:at + 24].split(b"\0")[0]
            fileoff, filesize = struct.unpack_from("<QQ", b, at + 40)
            nsects = struct.unpack_from("<I", b, at + 64)[0]
            if 72 + nsects * 80 != size:
                raise PreparationError("Invalid section count")
            if filesize and fileoff + filesize > len(b):
                raise PreparationError("Segment extends beyond executable")
            if segname == b"__TEXT":
                self.text_ranges.append((fileoff, fileoff + filesize))
            for i in range(nsects):
                section = at + 72 + 80 * i
                section_size = struct.unpack_from("<Q", b, section + 40)[0]
                offset, _, reloff, nreloc, flags = struct.unpack_from("<IIIII", b, section + 48)
                name = b[section:section + 16].split(b"\0")[0].decode("ascii", "replace")
                if section_size and (flags & 0xFF) not in {1, 0xC, 0x12}:
                    if offset + section_size > len(b) or offset < fileoff or offset + section_size > fileoff + filesize:
                        raise PreparationError(f"File-backed section {name} is outside its segment")
                    self.file_sections.append((offset, section_size, name))
                self._range(reloff, nreloc * 8, "section relocations")
        elif cmd == 0x2:  # LC_SYMTAB
            if size != 24:
                raise PreparationError("Malformed symbol table command")
            symoff, nsyms, stroff, strsize = struct.unpack_from("<IIII", b, at + 8)
            self._range(symoff, nsyms * 16, "symbol table")
            self._range(stroff, strsize, "string table")
        elif cmd == 0xB:  # LC_DYSYMTAB: indexed symbol subsets plus six file ranges.
            if size != 80:
                raise PreparationError("Malformed dynamic-symbol-table command")
            fields = struct.unpack_from("<18I", b, at + 8)
            for slot, item_size, label in ((6, 8, "table of contents"), (8, 56, "module table"),
                                          (10, 4, "external references"), (12, 4, "indirect symbols"),
                                          (14, 8, "external relocations"), (16, 8, "local relocations")):
                self._range(fields[slot], fields[slot + 1] * item_size, label)
        elif cmd in {0x22, 0x80000022}:  # LC_DYLD_INFO[_ONLY]
            if size != 48:
                raise PreparationError("Malformed dyld-info command")
            for field in range(5):
                offset, length = struct.unpack_from("<II", b, at + 8 + field * 8)
                self._range(offset, length, "dyld info")
        elif cmd in {0x1D, 0x1E, 0x26, 0x29, 0x2B, 0x2E, 0x80000033, 0x80000034, 0x36, 0x37, 0x38}:
            if size != 16:
                raise PreparationError("Malformed linkedit-data command")
            self._range(*struct.unpack_from("<II", b, at + 8), "linkedit data")
        elif cmd == 0x80000028:  # LC_MAIN
            if size != 24:
                raise PreparationError("Malformed entry point command")
            self._range(struct.unpack_from("<Q", b, at + 8)[0], 1, "entry point")
        elif cmd == 0x31:  # LC_NOTE
            if size != 40:
                raise PreparationError("Malformed note command")
            self._range(*struct.unpack_from("<QQ", b, at + 24), "note data")

    def inject(self) -> tuple[bytes, dict]:
        if INJECT_PATH in self.dependencies:
            return self.blob, {"status": "already_present", "path": INJECT_PATH, "bytes_added": 0}
        # A different SDKtools path would cause potentially ambiguous double loading.
        if any(PurePosixPath(p).name == "SDKtools.dylib" for p in self.dependencies):
            raise PreparationError("SDKtools already has a different dependency path; manual review required")
        encoded = INJECT_PATH.encode("utf-8") + b"\0"
        command_size = (24 + len(encoded) + 7) & ~7
        end = self.header_end + command_size
        first_data = min([x[0] for x in self.file_sections] + self.other_data_starts)
        if end > first_data:
            raise PreparationError(f"Insufficient header padding: need {command_size}, have {first_data - self.header_end} bytes")
        if not any(start == 0 and end <= stop for start, stop in self.text_ranges):
            raise PreparationError("New load command would not fit in the original __TEXT file range")
        if any(self.blob[self.header_end:end]):
            raise PreparationError("Header padding is not entirely zero; refusing to overwrite data")
        command = struct.pack("<IIIIII", LC_LOAD_DYLIB, command_size, 24, 0, 0, 0) + encoded
        command = command.ljust(command_size, b"\0")
        changed = bytearray(self.blob)
        changed[self.header_end:end] = command
        struct.pack_into("<II", changed, 16, self.ncmds + 1, self.sizeofcmds + command_size)
        updated = bytes(changed)
        checked = MachO(updated, expected_type=MH_EXECUTE)
        if checked.dependencies.count(INJECT_PATH) != 1 or len(updated) != len(self.blob):
            raise PreparationError("Post-injection Mach-O verification failed")
        if updated[end:] != self.blob[end:]:
            raise PreparationError("Bytes beyond the load command unexpectedly changed")
        return updated, {"status": "injected", "path": INJECT_PATH, "bytes_added": command_size,
                         "header_padding_before": first_data - self.header_end,
                         "new_load_command_file_offset": self.header_end}


def read_entry(archive: zipfile.ZipFile, name: str, maximum: int) -> bytes:
    info = archive.getinfo(name)
    if info.file_size > maximum:
        raise PreparationError(f"Entry exceeds bounded read limit: {name}")
    with archive.open(info) as stream:
        data = stream.read(maximum + 1)
    if len(data) != info.file_size or len(data) > maximum:
        raise PreparationError(f"Entry size mismatch: {name}")
    return data


def resource_files(root: Path, limits: Limits) -> list[tuple[Path, str]]:
    if root.is_symlink() or not root.is_dir():
        raise PreparationError("Resources must be a real directory, not a symlink")
    files = []
    total = 0
    for directory, dirs, names in os.walk(root, followlinks=False):
        for name in sorted(dirs + names):
            file = Path(directory) / name
            attributes = file.lstat()
            if stat.S_ISLNK(attributes.st_mode) or not (stat.S_ISDIR(attributes.st_mode) or stat.S_ISREG(attributes.st_mode)):
                raise PreparationError(f"Symlink or special resource is unsupported: {file}")
            if stat.S_ISDIR(attributes.st_mode):
                continue
            relative = file.relative_to(root).as_posix()
            safe_zip_name(relative)
            if attributes.st_size > limits.entry_bytes:
                raise PreparationError(f"Resource exceeds size limit: {relative}")
            total += attributes.st_size
            if total > limits.total_bytes or len(files) >= limits.entries:
                raise PreparationError("Resource tree exceeds size/count limits")
            files.append((file, relative))
    if not files:
        raise PreparationError("Resource bundle is empty")
    return sorted(files, key=lambda item: item[1])


def stream_copy(source, destination) -> tuple[str, int]:
    digest, count = hashlib.sha256(), 0
    while True:
        chunk = source.read(CHUNK)
        if not chunk:
            break
        destination.write(chunk)
        digest.update(chunk)
        count += len(chunk)
    return digest.hexdigest(), count


def hash_stream(source) -> str:
    digest = hashlib.sha256()
    for chunk in iter(lambda: source.read(CHUNK), b""):
        digest.update(chunk)
    return digest.hexdigest()


def new_info(name: str, mode: int = 0o644) -> zipfile.ZipInfo:
    item = zipfile.ZipInfo(name, (2020, 1, 1, 0, 0, 0))
    item.compress_type = zipfile.ZIP_DEFLATED
    item.create_system = 3
    item.external_attr = (stat.S_IFREG | mode) << 16
    return item


def prepare(ipa: Path, dylib: Path, resources: Path, output: Path, *, limits: Limits = Limits()) -> dict:
    ipa, dylib, resources, output = map(Path, (ipa, dylib, resources, output))
    if not ipa.is_file() or not dylib.is_file():
        raise PreparationError("Input IPA and dylib must exist as files")
    if output.resolve() == ipa.resolve() or os.path.lexists(output):
        raise PreparationError("Output must be a new path; original/existing files are never overwritten")
    if not output.parent.is_dir():
        raise PreparationError("Output directory does not exist")
    if dylib.stat().st_size > MAX_MACHO:
        raise PreparationError("Dylib exceeds supported bounded-read size")
    dylib_bytes = dylib.read_bytes()
    library = MachO(dylib_bytes, expected_type=MH_DYLIB)
    if len(library.install_names) != 1 or library.install_names[0] not in ALLOWED_INSTALL_NAMES:
        raise PreparationError("SDKtools dylib must have one supported LC_ID_DYLIB install name")
    bundle_files = resource_files(resources, limits)
    temporary: Path | None = None
    try:
        with zipfile.ZipFile(ipa) as source:
            infos = validate_zip(source, limits)
            plist_names = [i.filename for i in infos if re.fullmatch(r"Payload/[^/]+\.app/Info\.plist", i.filename)]
            if len(plist_names) != 1:
                raise PreparationError("IPA must contain exactly one top-level application Info.plist")
            plist_name = plist_names[0]
            app_prefix = plist_name[:-len("Info.plist")]
            try:
                plist = plistlib.loads(read_entry(source, plist_name, 4 * 1024**2))
            except (plistlib.InvalidFileException, ValueError, TypeError) as exc:
                raise PreparationError("Cannot parse application Info.plist") from exc
            if not isinstance(plist, dict):
                raise PreparationError("Info.plist root must be a dictionary")
            executable = plist.get("CFBundleExecutable")
            if not isinstance(executable, str) or "/" in executable:
                raise PreparationError("Invalid CFBundleExecutable")
            safe_zip_name(executable)
            executable_path = app_prefix + executable
            try:
                original_binary = read_entry(source, executable_path, MAX_MACHO)
            except KeyError as exc:
                raise PreparationError("CFBundleExecutable is missing from IPA") from exc
            application = MachO(original_binary, expected_type=MH_EXECUTE)
            minimum = version_tuple(plist.get("MinimumOSVersion"))
            if application.minimum_ios > minimum:
                raise PreparationError("Executable requires newer iOS than Info.plist declares")
            if library.minimum_ios > minimum:
                raise PreparationError("SDKtools dylib requires newer iOS than this application minimum")
            modified_binary, injection = application.inject()
            dylib_target = app_prefix + "Frameworks/SDKtools.dylib"
            bundle_target = app_prefix + "SDKtools.bundle/"
            signature_prefix = app_prefix + "_CodeSignature/"
            removed = []
            expected: dict[str, tuple[str, int]] = {}
            fd, temp_name = tempfile.mkstemp(prefix=".sdktools-", suffix=".ipa.tmp", dir=output.parent)
            os.close(fd)
            temporary = Path(temp_name)
            with zipfile.ZipFile(temporary, "w", allowZip64=True) as target:
                target.comment = source.comment
                for info in infos:
                    name = info.filename
                    if name == dylib_target or name == bundle_target.rstrip("/") or name.startswith(bundle_target):
                        continue
                    if name.rstrip("/") == signature_prefix.rstrip("/") or name.startswith(signature_prefix):
                        removed.append(name)
                        continue
                    entry = copy.copy(info)
                    if name == executable_path:
                        target.writestr(entry, modified_binary)
                        expected[name] = (hashlib.sha256(modified_binary).hexdigest(), len(modified_binary))
                    else:
                        with source.open(info) as reader, target.open(entry, "w", force_zip64=info.file_size >= 2**31) as writer:
                            expected[name] = stream_copy(reader, writer)
                target.writestr(new_info(dylib_target, 0o755), dylib_bytes)
                expected[dylib_target] = (hashlib.sha256(dylib_bytes).hexdigest(), len(dylib_bytes))
                for file, relative in bundle_files:
                    name = bundle_target + relative
                    with file.open("rb") as reader, target.open(new_info(name), "w", force_zip64=file.stat().st_size >= 2**31) as writer:
                        expected[name] = stream_copy(reader, writer)
            with zipfile.ZipFile(temporary) as verified:
                validate_zip(verified, limits)
                if set(verified.namelist()) != set(expected):
                    raise PreparationError("Output archive path verification failed")
                for name, (expected_hash, expected_size) in expected.items():
                    if verified.getinfo(name).file_size != expected_size:
                        raise PreparationError(f"Output size verification failed: {name}")
                    with verified.open(name) as reader:
                        if hash_stream(reader) != expected_hash:
                            raise PreparationError(f"Output content verification failed: {name}")
                bad = verified.testzip()
                if bad is not None:
                    raise PreparationError(f"Output CRC validation failed: {bad}")
                final_binary = read_entry(verified, executable_path, MAX_MACHO)
                checked = MachO(final_binary, expected_type=MH_EXECUTE)
                if checked.dependencies.count(INJECT_PATH) != 1:
                    raise PreparationError("SDKtools load command is missing or duplicated")
            with temporary.open("rb") as handle:
                prepared_hash = hash_stream(handle)
                os.fsync(handle.fileno())
            # link() is an atomic, no-overwrite publication on the same filesystem.
            # There is intentionally no overwrite-prone rename/copy fallback.
            try:
                os.link(temporary, output)
            except FileExistsError as exc:
                raise PreparationError("Output appeared during preparation; refusing to overwrite it") from exc
            temporary.unlink()
            temporary = None
            return {"status": "UNSIGNED_REQUIRES_RECURSIVE_RESIGNING", "output": str(output.resolve()),
                    "output_sha256": prepared_hash, "app_bundle_id": plist.get("CFBundleIdentifier"),
                    "executable": executable_path, "minimum_ios": version_string(minimum),
                    "dylib_minimum_ios": version_string(library.minimum_ios), "load_command": injection,
                    "removed_main_signature_entries": removed, "verified_entries": len(expected),
                    "verification": ["streamed_content_sha256", "zip_crc_testzip", "macho_load_command"],
                    "notice": "No signing, decryption, device launch, or GBox compatibility test was performed. Existing nested signatures may remain; sign nested code first, main app last."}
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ipa", required=True, type=Path)
    parser.add_argument("--dylib", required=True, type=Path)
    parser.add_argument("--resources", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path, help="New UNSIGNED IPA path; never overwritten")
    args = parser.parse_args()
    try:
        result = prepare(args.ipa, args.dylib, args.resources, args.output)
    except (PreparationError, OSError, zipfile.BadZipFile, RuntimeError) as exc:
        print(f"SDKtools preparation failed: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
